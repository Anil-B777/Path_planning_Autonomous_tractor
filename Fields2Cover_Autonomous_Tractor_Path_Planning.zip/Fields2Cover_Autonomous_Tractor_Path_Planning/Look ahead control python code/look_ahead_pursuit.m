clc; clear; close all;

 a1 = 0.15; a2 = 0.08;
 t1 = 0.06; t2 = 0.04;
 D = 0.2; d = 0.1; l = 2.5; b = 0.10;
%% Parameters
L = 2.5;                      % wheelbase
v = 5.0;                      % constant speed
dt = 0.05;                    % time step
lookahead = 2.0;              % lookahead distance
swath_width = 6;
num_swaths = 5;
field_length = 40;
turn_radius = swath_width / 2;   % U-turn radius

%% Generate Complete Path (Straight + U-turns)
path = [];

for i = 1:num_swaths
    y_swath = (i-1) * swath_width;
    
    % Straight swath
    if mod(i,2)==1
        x_straight = linspace(0, field_length, 100);
    else
        x_straight = linspace(field_length, 0, 100);
    end
    y_straight = y_swath * ones(size(x_straight));
    path = [path [x_straight; y_straight]];
    
    % Add U-turn to next swath (skip for last swath)
    if i < num_swaths
        cx = (mod(i,2)==1)*field_length + (mod(i,2)==0)*0;
        cx = cx + (mod(i,2)==1)*turn_radius - (mod(i,2)==0)*turn_radius;
        cy = y_swath + swath_width/2;
        
        if mod(i,2)==1
            theta = linspace(-pi/2, pi/2, 50);  % right to left
        else
            theta = linspace(pi/2, 3*pi/2, 50); % left to right
        end
        
        x_turn = cx + turn_radius*cos(theta);
        y_turn = cy + turn_radius*sin(theta);
        path = [path [x_turn; y_turn]];
    end
end

%% Initial State
x = 0; y = 0; theta = 0;
traj = [x; y];

idx = 1;

%% Simulation
for t = 0:dt:300
    if idx > size(path,2)
        break;
    end

    % Lookahead target point
    while idx < size(path,2)
        dx = path(1,idx) - x;
        dy = path(2,idx) - y;
        if hypot(dx, dy) > lookahead
            break;
        end
        idx = idx + 1;
    end

    target = path(:, idx);
    dx = target(1) - x;
    dy = target(2) - y;

    % Pure Pursuit Steering
    local_x = cos(theta)*dx + sin(theta)*dy;
    local_y = -sin(theta)*dx + cos(theta)*dy;
    alpha = atan2(local_y, local_x);
    steer = atan2(2*L*sin(alpha)/lookahead, 1);
    
    % Bicycle model update
    x = x + v*cos(theta)*dt;
    y = y + v*sin(theta)*dt;
    theta = theta + v/L * tan(steer) * dt;

    traj = [traj [x; y]];

    % Plot
    clf; hold on; axis equal;
    plot(path(1,:), path(2,:), 'k--', 'LineWidth', 1);
    plot(traj(1,:), traj(2,:), 'b', 'LineWidth', 2);
    plot(x, y, 'ro', 'MarkerFaceColor', 'r');
    xlim([-5 field_length+5]);
    ylim([-5 num_swaths*swath_width+5]);
    title(sprintf('Time: %.1f sec', t));
    drawnow;


end
