import numpy as np
from math import tan, atan2, acos, pi, sin, cos, sqrt

import numpy as np
import matplotlib.pyplot as plt


class Car:
    """Simple car model with parameters directly provided."""
    
    def __init__(self, length, width, max_phi):
        self.l = length      # car length
        self.carw = width    # car width
        self.max_phi = max_phi  # maximum steering angle in radians
        self.r = self.l / tan(self.max_phi)

    def get_car_bounding(self, pos):
        """Get the bounding box of the car at a given position."""
        x, y, theta = pos
        
        # Define the four corners of the car relative to its center
        corners = [
            [self.l/2, self.carw/2],
            [self.l/2, -self.carw/2],
            [-self.l/2, -self.carw/2],
            [-self.l/2, self.carw/2]
        ]
        
        # Rotate and translate the corners based on car's position and orientation
        rotated_corners = []
        for corner in corners:
            rotated_x = corner[0] * cos(theta) - corner[1] * sin(theta) + x
            rotated_y = corner[0] * sin(theta) + corner[1] * cos(theta) + y
            rotated_corners.append([rotated_x, rotated_y])
            
        return rotated_corners


def transform(x, y, dx, dy, theta, opt):
    """
    Transform a point (dx, dy) from car's local coordinate to world coordinate.
    opt: 1 for left, 2 for right
    """
    if opt == 1:  # left
        tx = x + dx * cos(theta) - dy * sin(theta)
        ty = y + dx * sin(theta) + dy * cos(theta)
    else:  # right
        tx = x + dx * cos(theta) + dy * sin(theta)
        ty = y + dx * sin(theta) - dy * cos(theta)
    
    return np.array([tx, ty])


def directional_theta(v1, v2, d):
    """Calculate the directional angle between two vectors."""
    theta1 = atan2(v1[1], v1[0])
    theta2 = atan2(v2[1], v2[0])
    
    if d > 0:  # left turn
        if theta2 < theta1:
            theta2 += 2 * pi
        return theta2 - theta1
    else:  # right turn
        if theta2 > theta1:
            theta2 -= 2 * pi
        return theta2 - theta1


def distance(p1, p2):
    """Calculate Euclidean distance between two points."""
    return sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)


class Params:
    """Store parameters for different dubins paths."""

    def __init__(self, d):
        self.d = d      # dubins type
        self.t1 = None  # first tangent point
        self.t2 = None  # second tangent point
        self.c1 = None  # first center point
        self.c2 = None  # second center point
        self.len = None # total travel distance


class DubinsPath:
    """
    Consider four dubins paths
    - LSL
    - LSR
    - RSL
    - RSR
    and find the shortest one.
    """

    def __init__(self, car):
        self.car = car
        self.r = self.car.l / tan(self.car.max_phi)
        
        # turn left: 1, turn right: -1
        self.direction = {
            'LSL': [1, 1],
            'LSR': [1, -1],
            'RSL': [-1, 1],
            'RSR': [-1, -1]
        }
    
    def find_tangents(self, start_pos, end_pos):
        """Find the tangents of four dubins paths."""
        self.start_pos = start_pos
        self.end_pos = end_pos

        x1, y1, theta1 = start_pos
        x2, y2, theta2 = end_pos
        
        self.s = np.array(start_pos[:2])
        self.e = np.array(end_pos[:2])
        
        self.lc1 = transform(x1, y1, 0, self.r, theta1, 1)
        self.rc1 = transform(x1, y1, 0, self.r, theta1, 2)
        self.lc2 = transform(x2, y2, 0, self.r, theta2, 1)
        self.rc2 = transform(x2, y2, 0, self.r, theta2, 2)
        
        solutions = [self._LSL(), self._LSR(), self._RSL(), self._RSR()]
        solutions = [s for s in solutions if s is not None]
        solutions.sort(key=lambda x: x.len, reverse=False)
        
        return solutions
    
    def get_params(self, dub, c1, c2, t1, t2):
        """Calculate the dubins path length."""
        v1 = self.s - c1
        v2 = t1 - c1
        v3 = t2 - t1
        v4 = t2 - c2
        v5 = self.e - c2

        delta_theta1 = directional_theta(v1, v2, dub.d[0])
        delta_theta2 = directional_theta(v4, v5, dub.d[1])

        arc1 = abs(delta_theta1 * self.r)
        tangent = np.linalg.norm(v3)
        arc2 = abs(delta_theta2 * self.r)

        theta = self.start_pos[2] + delta_theta1

        dub.t1 = t1.tolist() + [theta]
        dub.t2 = t2.tolist() + [theta]
        dub.c1 = c1
        dub.c2 = c2
        dub.len = arc1 + tangent + arc2
        
        return dub
    
    def _LSL(self):
        lsl = Params(self.direction['LSL'])

        cline = self.lc2 - self.lc1
        R = np.linalg.norm(cline) / 2
        theta = atan2(cline[1], cline[0]) - acos(0)

        t1 = transform(self.lc1[0], self.lc1[1], self.r, 0, theta, 1)
        t2 = transform(self.lc2[0], self.lc2[1], self.r, 0, theta, 1)

        lsl = self.get_params(lsl, self.lc1, self.lc2, t1, t2)
        return lsl

    def _LSR(self):
        lsr = Params(self.direction['LSR'])

        cline = self.rc2 - self.lc1
        R = np.linalg.norm(cline) / 2

        if R < self.r:
            return None
        
        theta = atan2(cline[1], cline[0]) - acos(self.r/R)

        t1 = transform(self.lc1[0], self.lc1[1], self.r, 0, theta, 1)
        t2 = transform(self.rc2[0], self.rc2[1], self.r, 0, theta+pi, 1)

        lsr = self.get_params(lsr, self.lc1, self.rc2, t1, t2)
        return lsr

    def _RSL(self):
        rsl = Params(self.direction['RSL'])

        cline = self.lc2 - self.rc1
        R = np.linalg.norm(cline) / 2

        if R < self.r:
            return None
        
        theta = atan2(cline[1], cline[0]) + acos(self.r/R)

        t1 = transform(self.rc1[0], self.rc1[1], self.r, 0, theta, 1)
        t2 = transform(self.lc2[0], self.lc2[1], self.r, 0, theta+pi, 1)

        rsl = self.get_params(rsl, self.rc1, self.lc2, t1, t2)
        return rsl

    def _RSR(self):
        rsr = Params(self.direction['RSR'])

        cline = self.rc2 - self.rc1
        R = np.linalg.norm(cline) / 2
        theta = atan2(cline[1], cline[0]) + acos(0)

        t1 = transform(self.rc1[0], self.rc1[1], self.r, 0, theta, 1)
        t2 = transform(self.rc2[0], self.rc2[1], self.r, 0, theta, 1)

        rsr = self.get_params(rsr, self.rc1, self.rc2, t1, t2)
        return rsr
    
    def get_best_path(self, start_pos, end_pos):
        """Get the shortest dubins path."""
        solutions = self.find_tangents(start_pos, end_pos)
        
        if not solutions:
            return None, float('inf')
            
        best_solution = solutions[0]  # Solutions are already sorted by length
        route = self.get_route(best_solution)
        
        return route, best_solution
    
    def get_route(self, s):
        """Get the route of dubins path."""
        phi1 = self.car.max_phi if s.d[0] == 1 else -self.car.max_phi
        phi2 = self.car.max_phi if s.d[1] == 1 else -self.car.max_phi

        phil = [phi1, 0, phi2]   #first_arc_angle, straight_line angle, second_arc_angle
        goal = [s.t1, s.t2, self.end_pos]   #first_arc_end, second_arc_start, second_arc_end
        ml = [1, 1, 1]
        
        return list(zip(goal, phil, ml))


def plot_dubins_path(car, solution, start_pos, end_pos):
    """Plot the Dubins path."""
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # Plot start and end positions
    ax.plot(start_pos[0], start_pos[1], 'go', markersize=10, label='Start')  #start
    ax.plot(end_pos[0], end_pos[1], 'ro', markersize=10, label='End')  #end
    
    # Draw car at start and end positions
    draw_car(ax, car, start_pos, 'green')
    draw_car(ax, car, end_pos, 'red')
    
    # Plot path components
    if solution.d[0] == 1:  # First arc (Left)
        plot_arc(ax, solution.c1, car.r, start_pos, solution.t1, 'blue')
    else:  # First arc (Right)
        plot_arc(ax, solution.c1, car.r, start_pos, solution.t1, 'blue', clockwise=True)
    
    # Straight segment
    ax.plot([solution.t1[0], solution.t2[0]], [solution.t1[1], solution.t2[1]], 'b-', linewidth=2)
    
    # Draw first tangent point
    ax.plot(solution.t1[0], solution.t1[1], 'bx', markersize=8)
    
    if solution.d[1] == 1:  # Second arc (Left)
        plot_arc(ax, solution.c2, car.r, solution.t2, end_pos, 'blue')
    else:  # Second arc (Right)
        plot_arc(ax, solution.c2, car.r, solution.t2, end_pos, 'blue', clockwise=True)
    
    # Draw second tangent point
    ax.plot(solution.t2[0], solution.t2[1], 'bx', markersize=8)
    
    # Draw circles for turning radius
    circle1 = plt.Circle((solution.c1[0], solution.c1[1]), car.r, color='lightblue', fill=False, linestyle='--')
    circle2 = plt.Circle((solution.c2[0], solution.c2[1]), car.r, color='lightblue', fill=False, linestyle='--')
    ax.add_artist(circle1)
    ax.add_artist(circle2)
    
    # Path type and length
    path_type = ''
    if solution.d[0] == 1 and solution.d[1] == 1:
        path_type = 'LSL'
    elif solution.d[0] == 1 and solution.d[1] == -1:
        path_type = 'LSR'
    elif solution.d[0] == -1 and solution.d[1] == 1:
        path_type = 'RSL'
    elif solution.d[0] == -1 and solution.d[1] == -1:
        path_type = 'RSR'
    
    ax.set_title(f'Dubins Path: {path_type}, Length: {solution.len:.2f}')
    
    # Set equal aspect ratio
    ax.set_aspect('equal')
    ax.grid(True)
    ax.legend()
    
    plt.show()
    
    return fig, ax


def draw_car(ax, car, pos, color):
    """Draw car as a rectangle at the given position."""
    x, y, theta = pos
    
    corners = car.get_car_bounding(pos)
    corners.append(corners[0])  # Close the rectangle
    
    xs, ys = zip(*corners)
    ax.plot(xs, ys, color=color, linewidth=2)
    
    # Draw direction indicator
    front_x = x + car.l/2 * cos(theta)
    front_y = y + car.l/2 * sin(theta)
    ax.plot([x, front_x], [y, front_y], color=color, linewidth=2)


def plot_arc(ax, center, radius, start_pos, end_pos, color, clockwise=False):
    """Plot an arc from start_pos to end_pos with given center and radius."""
    cx, cy = center
    
    # Calculate angles
    start_angle = atan2(start_pos[1] - cy, start_pos[0] - cx)
    end_angle = atan2(end_pos[1] - cy, end_pos[0] - cx)
    
    # Ensure correct direction
    if clockwise:
        if end_angle > start_angle:
            end_angle -= 2 * pi
    else:
        if end_angle < start_angle:
            end_angle += 2 * pi
    
    # Generate points along the arc
    num_points = 100
    if clockwise:
        theta = np.linspace(start_angle, end_angle, num_points)
    else:
        theta = np.linspace(start_angle, end_angle, num_points)
    
    x = cx + radius * np.cos(theta)
    y = cy + radius * np.sin(theta)
    
    ax.plot(x, y, color=color, linewidth=2)




def get_dubins_path_points(start_pos, end_pos, car_length, car_width, max_steering_angle_degrees, num_points=100):
    """
    Extract the sample points along the shortest Dubins path.
    
    Parameters:
    - start_pos: tuple (x, y, theta) - starting position and orientation
    - end_pos: tuple (x, y, theta) - ending position and orientation
    - car_length: float - length of the car
    - car_width: float - width of the car
    - max_steering_angle_degrees: float - maximum steering angle in degrees
    - num_points: int - number of points to sample for each segment (default: 100)
    
    Returns:
    - path_points: list of (x, y) points along the path
    - path_type: string indicating the type of Dubins path (LSL, LSR, RSL, RSR)
    - path_length: length of the path
    """
    # Convert steering angle from degrees to radians
    max_steering_angle_rad = max_steering_angle_degrees * pi / 180
    
    # Create a car object
    car = Car(car_length, car_width, max_steering_angle_rad)
    
    # Create Dubins path planner
    dubins = DubinsPath(car)
    
    # Find the best path
    route, solution = dubins.get_best_path(start_pos, end_pos)
    
    if solution is None:
        return [], "", float('inf')
    
    # Extract points along the path
    path_points = []
    
    # First arc
    first_arc_points = sample_arc_points(
        solution.c1, 
        car.r, 
        start_pos, 
        solution.t1, 
        solution.d[0] == 1,  # counterclockwise if d[0] == 1 (Left)
        num_points
    )
    path_points.extend(first_arc_points)
    
    # Straight segment
    straight_points = sample_straight_line_points(
        solution.t1[:2],  # Convert from [x, y, theta] to [x, y]
        solution.t2[:2], 
        num_points
    )
    path_points.extend(straight_points)
    
    # Second arc
    second_arc_points = sample_arc_points(
        solution.c2, 
        car.r, 
        solution.t2, 
        end_pos, 
        solution.d[1] == 1,  # counterclockwise if d[1] == 1 (Left)
        num_points
    )
    path_points.extend(second_arc_points)
    
    # Determine path type
    path_type = ""
    if solution.d[0] == 1 and solution.d[1] == 1:
        path_type = "LSL"
    elif solution.d[0] == 1 and solution.d[1] == -1:
        path_type = "LSR"
    elif solution.d[0] == -1 and solution.d[1] == 1:
        path_type = "RSL"
    elif solution.d[0] == -1 and solution.d[1] == -1:
        path_type = "RSR"
    
    return path_points, path_type, solution.len


def sample_arc_points(center, radius, start_pos, end_pos, counterclockwise=True, num_points=100):
    """
    Sample points along an arc from start_pos to end_pos.
    
    Parameters:
    - center: tuple (x, y) - center of the arc
    - radius: float - radius of the arc
    - start_pos: tuple (x, y, theta) or (x, y) - starting position
    - end_pos: tuple (x, y, theta) or (x, y) - ending position
    - counterclockwise: bool - True for counterclockwise, False for clockwise
    - num_points: int - number of points to sample
    
    Returns:
    - points: list of (x, y) points along the arc
    """
    cx, cy = center
    
    # Extract x, y from positions
    start_x = start_pos[0]
    start_y = start_pos[1]
    end_x = end_pos[0]
    end_y = end_pos[1]
    
    # Calculate angles
    start_angle = atan2(start_y - cy, start_x - cx)
    end_angle = atan2(end_y - cy, end_x - cx)
    
    # Ensure correct direction
    if not counterclockwise:  # clockwise
        if end_angle > start_angle:
            end_angle -= 2 * pi
    else:  # counterclockwise
        if end_angle < start_angle:
            end_angle += 2 * pi
    
    # Generate points along the arc
    theta = np.linspace(start_angle, end_angle, num_points)
    x = cx + radius * np.cos(theta)
    y = cy + radius * np.sin(theta)
    
    return list(zip(x, y))


def sample_straight_line_points(start_point, end_point, num_points=100):
    """
    Sample points along a straight line from start_point to end_point.
    
    Parameters:
    - start_point: tuple (x, y) - starting point
    - end_point: tuple (x, y) - ending point
    - num_points: int - number of points to sample
    
    Returns:
    - points: list of (x, y) points along the line
    """
    x = np.linspace(start_point[0], end_point[0], num_points)
    y = np.linspace(start_point[1], end_point[1], num_points)
    
    return list(zip(x, y))

def sample_straight_line_points(start_point, end_point, num_points=100):
    """
    Sample points along a straight line from start_point to end_point.
    
    Parameters:
    - start_point: tuple (x, y) - starting point
    - end_point: tuple (x, y) - ending point
    - num_points: int - number of points to sample
    
    Returns:
    - points: list of (x, y) points along the line
    """
    x = np.linspace(start_point[0], end_point[0], num_points)
    y = np.linspace(start_point[1], end_point[1], num_points)
    
    return list(zip(x, y))
