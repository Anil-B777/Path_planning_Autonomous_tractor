import numpy as np
import matplotlib.pyplot as plt

class TractorSimulator:
    def __init__(self, wheelbase=2.5, speed=8.0, dt=0.05, lookahead=2.0,
                 swath_width=5, num_swaths=9, field_length=40):
        self.L = wheelbase
        self.v = speed
        self.dt = dt
        self.lookahead = lookahead
        self.swath_width = swath_width
        self.num_swaths = num_swaths
        self.field_length = field_length
        self.turn_radius = swath_width / 2

        # Initial state
        self.x, self.y, self.theta = 0.0, 0.0, 0.0
        self.path = self.generate_path()
        self.idx = 0
        self.traj = [[self.x], [self.y]]
        self.THETA = []
        self.phi = []
        self.X = [self.x]
        self.Y = [self.y]

    def generate_path(self):
        path = []
        for i in range(1, self.num_swaths + 1):
            y_swath = (i - 1) * self.swath_width
            if i % 2 == 1:
                x_straight = np.linspace(0, self.field_length, 100)
            else:
                x_straight = np.linspace(self.field_length, 0, 100)
            y_straight = y_swath * np.ones_like(x_straight)
            path.append(np.vstack((x_straight, y_straight)))

            if i < self.num_swaths:
                cx = self.field_length + self.turn_radius if i % 2 == 1 else -self.turn_radius
                cy = y_swath + self.swath_width / 2
                theta = np.linspace(np.pi/2, np.pi/2, 50)
                x_turn = cx + self.turn_radius * np.cos(theta)
                y_turn = cy + self.turn_radius * np.sin(theta)
                path.append(np.vstack((x_turn, y_turn)))
        return np.hstack(path)

    def pure_pursuit_control(self):
        while self.idx < self.path.shape[1]:
            dx = self.path[0, self.idx] - self.x
            dy = self.path[1, self.idx] - self.y
            if np.hypot(dx, dy) > self.lookahead:
                break
            self.idx += 1

        if self.idx >= self.path.shape[1]:
            return None  # Path completed

        target = self.path[:, self.idx]
        dx = target[0] - self.x
        dy = target[1] - self.y
        local_x = np.cos(self.theta)*dx + np.sin(self.theta)*dy
        local_y = -np.sin(self.theta)*dx + np.cos(self.theta)*dy
        alpha = np.arctan2(local_y, local_x)
        steer = np.arctan2(2*self.L*np.sin(alpha)/self.lookahead, 1)
        return steer

    def update_state(self, steer):
        self.x += self.v * np.cos(self.theta) * self.dt
        self.y += self.v * np.sin(self.theta) * self.dt
        self.theta += self.v / self.L * np.tan(steer) * self.dt

        self.THETA.append(self.theta)
        self.phi.append(steer)
        self.X.append(self.x)
        self.Y.append(self.y)
        self.traj[0].append(self.x)
        self.traj[1].append(self.y)

    def run_simulation(self):
        fig, ax = plt.subplots()
        plt.title('Tractor Swath Tracking')
        ax.set_aspect('equal')

        while True:
            steer = self.pure_pursuit_control()
            if steer is None:
                break
            self.update_state(steer)

            # Plot field and path
            ax.clear()
            ax.plot([0, self.field_length, self.field_length, 0, 0],
                    [0, 0, self.swath_width * (self.num_swaths - 1),
                     self.swath_width * (self.num_swaths - 1), 0], 'k--')
            ax.plot(self.path[0], self.path[1], 'g--', label='Reference Path')
            ax.plot(self.X, self.Y, 'b-', label='Tractor Path')
            ax.plot(self.x, self.y, 'ro', label='Tractor')
            ax.legend()
            plt.pause(0.01)

        plt.show()

def main():
    simulator = TractorSimulator()
    simulator.run_simulation()

if __name__ == '__main__':
    main()
