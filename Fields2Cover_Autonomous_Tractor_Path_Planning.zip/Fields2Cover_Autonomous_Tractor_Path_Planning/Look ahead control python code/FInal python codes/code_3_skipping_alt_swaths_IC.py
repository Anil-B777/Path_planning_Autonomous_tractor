import numpy as np
import matplotlib.pyplot as plt


class TractorSwathTrackerOdd:
    def __init__(self):
        # Tractor geometry parameters
        self.a1, self.a2 = 0.15, 0.08
        self.t1, self.t2 = 0.06, 0.04
        self.D = 4 * 0.2
        self.d = 4 * 0.1
        self.b = 4 * 0.10

        # Parameters
        self.L = 6.0  # Wheelbase
        self.l = self.L
        self.v = 8.0  # Constant forward speed
        self.dt = 0.05
        self.lookahead = 2.0
        self.swath_width = 6
        self.num_swaths = 9
        self.field_length = 40
        self.turn_radius = self.swath_width / 8  # Smaller turn radius

        # Initial state
        self.x, self.y, self.theta = 0.0, 0.0, 0.0
        self.traj = np.array([[self.x], [self.y]])

        # Storage for history
        self.THETA = []
        self.phi = []
        self.X = []
        self.Y = []

        self.path = None

    def generate_path(self):
        path = np.empty((2, 0))
        odd_swaths = np.arange(1, self.num_swaths + 1, 2)  # [1,3,5,7,9]

        for idx, i in enumerate(odd_swaths, start=1):
            y_swath = (i - 1) * self.swath_width

            # Alternate directions for odd swaths
            if idx % 2 == 1:
                x_line = np.linspace(0, self.field_length, 100)
            else:
                x_line = np.linspace(self.field_length, 0, 100)
            y_line = y_swath * np.ones_like(x_line)
            segment = np.vstack((x_line, y_line))
            path = np.hstack((path, segment))

            # Add arc turn to next odd swath if not last
            if idx < len(odd_swaths):
                next_i = odd_swaths[idx]  # next odd swath index
                next_y = (next_i - 1) * self.swath_width

                if idx % 2 == 1:
                    # Left to right, arc outside RIGHT boundary
                    cx = self.field_length + self.turn_radius / 2
                    cy = (y_swath + next_y) / 2
                    theta = np.linspace(-np.pi / 2, np.pi / 2, 100)  # CCW arc
                else:
                    # Right to left, arc outside LEFT boundary
                    cx = -self.turn_radius / 2
                    cy = (y_swath + next_y) / 2
                    theta = np.linspace(3 * np.pi / 2, np.pi / 2, 100)  # CW arc

                x_arc = cx + self.turn_radius * np.cos(theta)
                y_arc = cy + self.turn_radius * np.sin(theta)
                arc_segment = np.vstack((x_arc, y_arc))
                path = np.hstack((path, arc_segment))

        self.path = path

    def run_simulation(self):
        idx = 0
        plt.ion()
        fig, ax = plt.subplots()
        ax.set_aspect('equal')
        plt.title('Tractor Swath Tracking - Odd Swaths with Arcs')

        while True:
            if idx >= self.path.shape[1]:
                self.v = 0  # Finished path
                break

            # Find pursuit target point on path
            while idx < self.path.shape[1]:
                dx = self.path[0, idx] - self.x
                dy = self.path[1, idx] - self.y
                if np.hypot(dx, dy) > self.lookahead:
                    break
                idx += 1
            if idx >= self.path.shape[1]:
                break

            target = self.path[:, idx]
            dx = target[0] - self.x
            dy = target[1] - self.y

            # Pure pursuit steering calculation
            local_x = np.cos(self.theta) * dx + np.sin(self.theta) * dy
            local_y = -np.sin(self.theta) * dx + np.cos(self.theta) * dy
            alpha = np.arctan2(local_y, local_x)
            steer = np.arctan2(2 * self.L * np.sin(alpha) / self.lookahead, 1)

            # Update tractor pose (bicycle model)
            self.x += self.v * np.cos(self.theta) * self.dt
            self.y += self.v * np.sin(self.theta) * self.dt
            self.theta += self.v / self.L * np.tan(steer) * self.dt

            self.THETA.append(self.theta)
            self.phi.append(steer)
            self.X.append(self.x)
            self.Y.append(self.y)
            self.traj = np.hstack((self.traj, np.array([[self.x], [self.y]])))

            # Clear and plot exactly as you gave
            ax.clear()
            ax.plot([0, self.field_length, self.field_length, 0, 0],
                    [0, 0, self.swath_width * (self.num_swaths - 1), self.swath_width * (self.num_swaths - 1), 0], 'g-', label='Field Boundary')
            ax.plot(self.path[0], self.path[1], 'k--', linewidth=1, label='Planned Path')
            ax.plot(self.traj[0], self.traj[1], 'b-', linewidth=2, label='Actual Trajectory')
            ax.plot(self.x, self.y, 'ro', markersize=8, label='Tractor Position')
            ax.set_xlim([-self.turn_radius - 5, self.field_length + self.turn_radius + 5])
            ax.set_ylim([-5, self.swath_width * self.num_swaths + 5])
            ax.set_xlabel('x [m]')
            ax.set_ylabel('y [m]')
            ax.grid(True)
            ax.legend()
            plt.pause(0.01)

        plt.ioff()

        # Final plot of swath lines (red dashed)
        for i in range(1, self.num_swaths + 1):
            y_swath = (i - 1) * self.swath_width
            if i % 2 == 1:
                x_line = [0, self.field_length]
            else:
                x_line = [self.field_length, 0]
            ax.plot(x_line, [y_swath, y_swath], 'r--', linewidth=1, label='Swath lines')

        plt.show()

    def run_realistic_animation(self):
        veh_box = np.array([[-self.b, self.b, self.b, self.l, self.l, self.b, self.b, -self.b, -self.b],
                            [-self.D, -self.D, -self.d, -self.d, self.d, self.d, self.D, self.D, -self.D]])
        w_s = np.array([[-self.a2, self.a2, self.a2, -self.a2, -self.a2],
                        [-self.t2 / 2, -self.t2 / 2, self.t2 / 2, self.t2 / 2, -self.t2 / 2]])
        w_b = np.array([[-self.a1, self.a1, self.a1, -self.a1, -self.a1],
                        [-self.t1 / 2, -self.t1 / 2, self.t1 / 2, self.t1 / 2, -self.t1 / 2]])

        fig2, ax2 = plt.subplots()
        ax2.plot([0, self.field_length, self.field_length, 0, 0],
                 [0, 0, self.swath_width * (self.num_swaths - 1), self.swath_width * (self.num_swaths - 1), 0], 'g-', linewidth=2)

        for i in range(0, len(self.X), 7):
            psi = self.THETA[i]
            R = np.array([[np.cos(psi), -np.sin(psi)], [np.sin(psi), np.cos(psi)]])

            v_m = R @ veh_box
            w_m3 = R @ (w_b + np.array([[0], [self.D + self.t1 / 2]]))
            w_m4 = R @ (w_b + np.array([[0], [-self.D - self.t1 / 2]]))

            R1 = np.array([[np.cos(self.phi[i]), -np.sin(self.phi[i])], [np.sin(self.phi[i]), np.cos(self.phi[i])]])
            w_m1 = R @ (R1 @ w_s + np.array([[self.l], [self.d + self.t2 / 2]]))
            w_m2 = R @ (R1 @ w_s + np.array([[self.l], [-self.d - self.t2 / 2]]))

            ax2.fill(v_m[0] + self.X[i], v_m[1] + self.Y[i], 'y')
            ax2.fill(w_m1[0] + self.X[i], w_m1[1] + self.Y[i], 'r')
            ax2.fill(w_m2[0] + self.X[i], w_m2[1] + self.Y[i], 'r')
            ax2.fill(w_m3[0] + self.X[i], w_m3[1] + self.Y[i], 'g')
            ax2.fill(w_m4[0] + self.X[i], w_m4[1] + self.Y[i], 'g')
            ax2.plot(self.X[:i + 1], self.Y[:i + 1], 'b-', linewidth=2)
            ax2.set_xlim(min(self.X) - 5, max(self.X) + 5)
            ax2.set_ylim(min(self.Y) - 5, max(self.Y) + 7)
            ax2.set_xlabel('x [m]')
            ax2.set_ylabel('y [m]')
            ax2.set_title('Tractor Animation')
            ax2.set_aspect('equal')
            ax2.grid(True)
            plt.pause(0.01)

        plt.show()

def main():
    tracker = TractorSwathTrackerOdd()
    tracker.generate_path()
    tracker.run_simulation()
    tracker.run_realistic_animation()


if __name__ == "__main__":
    main()
