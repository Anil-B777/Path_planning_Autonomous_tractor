import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.animation as animation

# Tractor geometry parameters
a1, a2 = 0.15, 0.08
t1, t2 = 0.06, 0.04
D = 4 * 0.2
d = 4 * 0.1
b = 4 * 0.10
L = 6.0  # Wheelbase
l=L
v = 16.0  # Constant speed
lookahead = 2.0
dt = 0.05
swath_width = 6
num_swaths = 9
field_length = 40
turn_radius = swath_width / 2

# Generate swaths
path = []
for i in range(num_swaths):
    y_swath = i * swath_width
    if i % 2 == 0:
        x_straight = np.linspace(0, field_length, 100)
    else:
        x_straight = np.linspace(field_length, 0, 100)
    y_straight = np.full_like(x_straight, y_swath)
    path.extend(list(zip(x_straight, y_straight)))

    if i < num_swaths - 1:
        cx = field_length + turn_radius if i % 2 == 0 else -turn_radius
        cy = y_swath + swath_width / 2
        if i % 2 == 0:
            theta = np.linspace(-np.pi / 2, np.pi / 2, 50)
        else:
            theta = np.linspace(3 * np.pi / 2, np.pi / 2, 50)
        x_turn = cx + turn_radius * np.cos(theta)
        y_turn = cy + turn_radius * np.sin(theta)
        path.extend(list(zip(x_turn, y_turn)))

path = np.array(path).T

# Initial state
x, y, theta = 0, 0, 0
traj = [[x], [y]]
idx = 0
X, Y, THETA, PHI = [], [], [], []

# Prepare animation
fig, ax = plt.subplots()
plt.title('Tractor Swath Tracking')
ax.set_aspect('equal')

while True:
    if idx >= path.shape[1]:
        break

    while idx < path.shape[1]:
        dx = path[0, idx] - x
        dy = path[1, idx] - y
        if np.hypot(dx, dy) > lookahead:
            break
        idx += 1

    if idx >= path.shape[1]:
        break

    target = path[:, idx]
    dx = target[0] - x
    dy = target[1] - y

    local_x = np.cos(theta) * dx + np.sin(theta) * dy
    local_y = -np.sin(theta) * dx + np.cos(theta) * dy
    alpha = np.arctan2(local_y, local_x)
    steer = np.arctan2(2 * L * np.sin(alpha) / lookahead, 1)

    x += v * np.cos(theta) * dt
    y += v * np.sin(theta) * dt
    theta += v / L * np.tan(steer) * dt

    X.append(x)
    Y.append(y)
    THETA.append(theta)
    PHI.append(steer)
    traj[0].append(x)
    traj[1].append(y)

    # Clear and plot
    ax.clear()
    ax.plot([0, field_length, field_length, 0, 0],
            [0, 0, swath_width * (num_swaths - 1), swath_width * (num_swaths - 1), 0], 'g-', label='Field Boundary')
    ax.plot(path[0], path[1], 'k--', linewidth=1, label='Planned Path')
    ax.plot(traj[0], traj[1], 'b-', linewidth=2, label='Actual Trajectory')
    ax.plot(x, y, 'ro', markersize=8, label='Tractor Position')
    ax.set_xlim([-turn_radius - 5, field_length + turn_radius + 5])
    ax.set_ylim([-5, swath_width * num_swaths + 5])
    ax.set_xlabel('x [m]')
    ax.set_ylabel('y [m]')
    ax.grid(True)
    ax.legend()
    plt.pause(0.01)

# Post-simulation animation with bounding box
veh_box = np.array([[-b,b,b,l,l,b,b,-b,-b], [-D,-D,-d,-d,d,d,D,D,-D]])
w_s = np.array([[-a2,a2,a2,-a2,-a2], [-t2/2,-t2/2,t2/2,t2/2,-t2/2]])
w_b = np.array([[-a1,a1,a1,-a1,-a1], [-t1/2,-t1/2,t1/2,t1/2,-t1/2]])

fig2, ax2 = plt.subplots()
ax2.plot([0, field_length, field_length, 0, 0],
         [0, 0, swath_width*(num_swaths-1), swath_width*(num_swaths-1), 0], 'g-', linewidth=2)

for i in range(0, len(X), 7):
    psi = THETA[i]
    R = np.array([[np.cos(psi), -np.sin(psi)], [np.sin(psi), np.cos(psi)]])

    v_m = R @ veh_box
    w_m3 = R @ (w_b + np.array([[0], [D + t1 / 2]]))
    w_m4 = R @ (w_b + np.array([[0], [-D - t1 / 2]]))

    R1 = np.array([[np.cos(PHI[i]), -np.sin(PHI[i])], [np.sin(PHI[i]), np.cos(PHI[i])]])
    w_m1 = R @ (R1 @ w_s + np.array([[l], [d + t2 / 2]]))
    w_m2 = R @ (R1 @ w_s + np.array([[l], [-d - t2 / 2]]))

    ax2.fill(v_m[0] + X[i], v_m[1] + Y[i], 'y')
    ax2.fill(w_m1[0] + X[i], w_m1[1] + Y[i], 'r')
    ax2.fill(w_m2[0] + X[i], w_m2[1] + Y[i], 'r')
    ax2.fill(w_m3[0] + X[i], w_m3[1] + Y[i], 'g')
    ax2.fill(w_m4[0] + X[i], w_m4[1] + Y[i], 'g')
    ax2.plot(X[:i+1], Y[:i+1], 'b-', linewidth=2)
    ax2.set_xlim(min(X)-5, max(X)+5)
    ax2.set_ylim(min(Y)-5, max(Y)+7)
    ax2.set_xlabel('x [m]')
    ax2.set_ylabel('y [m]')
    ax2.set_title('Tractor Animation')
    ax2.set_aspect('equal')
    ax2.grid(True)
    plt.pause(0.01)

plt.show()