import numpy as np
import matplotlib.pyplot as plt

# Tractor details
a1, a2 = 0.15, 0.08
t1, t2 = 0.06, 0.04
D = 4 * 0.2
d = 4 * 0.1
b = 4 * 0.10

# Parameters
L = 6.0  # Wheelbase (meters)
l = L
v = 8.0  # Constant forward speed (m/s)
dt = 0.05  # Simulation time step (seconds)
lookahead = 2.0  # Lookahead distance for pure pursuit (meters)
swath_width = 6  # Width between swaths (meters)
num_swaths = 9  # Number of swaths to cover
field_length = 40  # Length of the field (meters)
turn_radius = swath_width / 8  # Radius for U-turn arcs (meters)

# Generate path: Connect only odd swaths with alternating directions and arcs on correct sides
path = np.empty((2, 0))

odd_swaths = np.arange(1, num_swaths + 1, 2)  # [1,3,5,7,9]

for idx, i in enumerate(odd_swaths, start=1):
    y_swath = (i - 1) * swath_width
    
    # Alternate direction for odd swaths:
    if idx % 2 == 1:
        x_line = np.linspace(0, field_length, 100)
    else:
        x_line = np.linspace(field_length, 0, 100)
    y_line = y_swath * np.ones_like(x_line)
    
    segment = np.vstack((x_line, y_line))
    path = np.hstack((path, segment))
    
    # Add arc turn to next odd swath if not last
    if idx < len(odd_swaths):
        next_i = odd_swaths[idx]  # idx is 1-based in loop, so next is idx (python 0-based idx)
        next_y = (next_i - 1) * swath_width
        
        if idx % 2 == 1:
            # Current swath left-to-right => arc outside RIGHT boundary
            cx = field_length + turn_radius / 2
            cy = (y_swath + next_y) / 2
            theta = np.linspace(-np.pi/2, np.pi/2, 100)  # CCW arc bottom to top
        else:
            # Current swath right-to-left => arc outside LEFT boundary
            cx = -turn_radius / 2
            cy = (y_swath + next_y) / 2
            theta = np.linspace(3*np.pi/2, np.pi/2, 100)  # CW arc top to bottom
        
        x_arc = cx + turn_radius * np.cos(theta)
        y_arc = cy + turn_radius * np.sin(theta)
        
        arc_segment = np.vstack((x_arc, y_arc))
        path = np.hstack((path, arc_segment))

# Initial tractor state (start at beginning of swath 1)
x, y, theta = 0.0, 0.0, 0.0  # Starting pose
traj = np.array([[x], [y]])

idx = 0  # Index of current lookahead target point on path

THETA = []
phi = []
X = []
Y = []

# Simulation loop
plt.ion()
fig, ax = plt.subplots()


while True:
    if idx >= path.shape[1]:
        v = 0  # Finished path
        break
    
    # Find pursuit target point on path
    while idx < path.shape[1]:
        dx = path[0, idx] - x
        dy = path[1, idx] - y
        if np.hypot(dx, dy) > lookahead:
            break
        idx += 1
    if idx >= path.shape[1]:
        break
    
    target = path[:, idx]
    dx = target[0] - x
    dy = target[1] - y
    
    # Steering angle calculation using pure pursuit
    local_x = np.cos(theta) * dx + np.sin(theta) * dy
    local_y = -np.sin(theta) * dx + np.cos(theta) * dy
    alpha = np.arctan2(local_y, local_x)
    steer = np.arctan2(2 * L * np.sin(alpha) / lookahead, 1)
    
    # Bicycle model kinematics update
    x += v * np.cos(theta) * dt
    y += v * np.sin(theta) * dt
    theta += v / L * np.tan(steer) * dt
    
    THETA.append(theta)
    phi.append(steer)
    X.append(x)
    Y.append(y)
    traj = np.hstack((traj, np.array([[x], [y]])))
    
    # Clear and plot
    ax.clear()
    ax.plot([0, field_length, field_length, 0, 0],
            [0, 0, swath_width * (num_swaths - 1), swath_width * (num_swaths - 1), 0], 'g-', label='Field Boundary')
    ax.plot(path[0], path[1], 'k--', linewidth=1, label='Planned Path')
    ax.plot(traj[0], traj[1], 'b-', linewidth=2, label='Actual Trajectory')
    ax.plot(x, y, 'ro', markersize=8, label='Tractor Position')
    ax.set_xlim([-turn_radius - 5, field_length + turn_radius + 5])
    ax.set_ylim([-5, swath_width * num_swaths + 5])
    ax.set_xlabel('x [m]')
    ax.set_ylabel('y [m]')
    ax.grid(True)
    ax.legend()
    plt.pause(0.01)

for i in range(1, num_swaths + 1):
        y_swath = (i - 1) * swath_width
        if i % 2 == 1:
            x_line = [0, field_length]
        else:
            x_line = [field_length, 0]
        ax.plot(x_line, [y_swath, y_swath], 'r--', linewidth=1, label='Swath lines')
plt.ioff()

# Animation of tractor body and wheels
veh_box = np.array([
    [-b, b, b, l, l, b, b, -b, -b],
    [-D, -D, -d, -d, d, d, D, D, -D]
])

wheel_s = np.array([
    [-a2, a2, a2, -a2, -a2],
    [-t2/2, -t2/2, t2/2, t2/2, -t2/2]
])

wheel_b = np.array([
    [-a1, a1, a1, -a1, -a1],
    [-t1/2, -t1/2, t1/2, t1/2, -t1/2]
])

fig2, ax2 = plt.subplots()
ax2.plot([0, field_length, field_length, 0, 0],
         [0, 0, swath_width*(num_swaths-1), swath_width*(num_swaths-1), 0], 'g-', linewidth=2, label='Field Boundary')
    

for i in range(0, len(X), 5):
    psi = THETA[i]
    R = np.array([[np.cos(psi), -np.sin(psi)],
                  [np.sin(psi),  np.cos(psi)]])
    
    v_m = R @ veh_box
    w_m3 = R @ (wheel_b + np.array([[0], [D + t1/2]]))
    w_m4 = R @ (wheel_b + np.array([[0], [-D - t1/2]]))
    
    R1 = np.array([[np.cos(phi[i]), -np.sin(phi[i])],
                   [np.sin(phi[i]),  np.cos(phi[i])]])
    
    w_m1 = R @ (R1 @ wheel_s + np.array([[l], [d + t2/2]]))
    w_m2 = R @ (R1 @ wheel_s + np.array([[l], [-d - t2/2]]))
    
    #ax2.clear()
    
    ax2.fill(v_m[0, :] + X[i], v_m[1, :] + Y[i], 'y', label='Tractor')
    ax2.fill(w_m1[0, :] + X[i], w_m1[1, :] + Y[i], 'r')
    ax2.fill(w_m2[0, :] + X[i], w_m2[1, :] + Y[i], 'r')
    ax2.fill(w_m3[0, :] + X[i], w_m3[1, :] + Y[i], 'g')
    ax2.fill(w_m4[0, :] + X[i], w_m4[1, :] + Y[i], 'g')
    
    ax2.plot(X[:i+1], Y[:i+1], 'r', linewidth=2, label='Actual Trajectory')
    
    ax2.set_xlim(min(X) - 5, max(X) + 5)
    ax2.set_ylim(min(Y) - 5, max(Y) + 7)
    
    ax2.grid(True)
    ax2.set_xlabel('x, [m]')
    ax2.set_ylabel('y, [m]')
    ax2.tick_params(labelsize=14)
    
    plt.pause(0.01)

plt.show()
