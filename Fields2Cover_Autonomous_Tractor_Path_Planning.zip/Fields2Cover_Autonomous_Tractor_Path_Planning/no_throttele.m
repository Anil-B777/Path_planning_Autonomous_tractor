clc; clear;

%% Parameters
L = 1.0;           % Wheelbase [m]
v = 1.0;           % Constant forward velocity [m/s]
k_y = 15.0;         % Gain for lateral error
k_theta = 4.0;     % Gain for heading error

T = 40;            % Total simulation time [s]
dt = 0.01;         % Time step [s]
N = T/dt;          % Number of simulation steps

%% Preallocate
x = zeros(1,N); y = zeros(1,N); theta = zeros(1,N);     % Actual state
xd = zeros(1,N); yd = zeros(1,N); thetad = zeros(1,N);  % Desired trajectory
ey = zeros(1,N); etheta = zeros(1,N);                   % Errors

% Initial Conditions
x(1) = 0; y(1) = -1; theta(1) = pi/6;   % Initial robot pose

%% Desired Trajectory (Circle)
R = 5;  % Radius
omega_d = v / R;
for k = 1:N
    t = (k-1)*dt;
    xd(k) = R * cos(omega_d * t);
    yd(k) = R * sin(omega_d * t);
    thetad(k) = atan2(yd(k) - y(max(k-1,1)), xd(k) - x(max(k-1,1)));
end

thetad_dot = [diff(thetad)/dt, 0];

%% Main Control Loop
for k = 1:N-1
    % Errors in global frame
    dx = xd(k) - x(k);
    dy = yd(k) - y(k);

    % Transform to robot frame
    ex = cos(theta(k))*dx + sin(theta(k))*dy;
    ey(k) = -sin(theta(k))*dx + cos(theta(k))*dy;
    etheta(k) = thetad(k) - theta(k);
    etheta(k) = atan2(sin(etheta(k)), cos(etheta(k)));

    % Lyapunov-based control law
    omega = thetad_dot(k) + k_y * v * ey(k) + k_theta * sin(etheta(k));
    delta = atan2(L * omega, v);

    % Kinematic update
    x(k+1)     = x(k) + v * cos(theta(k)) * dt;
    y(k+1)     = y(k) + v * sin(theta(k)) * dt;
    theta(k+1) = theta(k) + omega * dt;
    theta(k+1) = atan2(sin(theta(k+1)), cos(theta(k+1)));
end

%% Plotting
figure;
plot(xd, yd, 'r--', 'LineWidth', 2); hold on;
plot(x, y, 'b-', 'LineWidth', 2);
legend('Desired Trajectory', 'Actual Path');
xlabel('X [m]'); ylabel('Y [m]');
title('Lyapunov-Based Trajectory Tracking');
axis equal; grid on;

figure;
subplot(2,1,1);
plot((0:N-1)*dt, ey); ylabel('e_y [m]');
title('Tracking Errors'); grid on;

subplot(2,1,2);
plot((0:N-1)*dt, etheta); ylabel('e_\theta [rad]');
xlabel('Time [s]'); grid on;
