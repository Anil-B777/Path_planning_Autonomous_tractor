import numpy as np
import matplotlib.pyplot as plt
from matplotlib import animation
from math import sin, cos, atan2, pi, sqrt

def wrapToPi(angle):
    return (angle + pi) % (2 * pi) - pi

def unicycle_tracking_control(x, y, theta, x_d, y_d, theta_d, v_d, omega_d, k1, k2):
    dx = x_d - x
    dy = y_d - y
    rho = sqrt(dx**2 + dy**2)
    alpha = wrapToPi(atan2(dy, dx) - theta)
    delta = wrapToPi(alpha + theta - theta_d)
    
    if abs(alpha) > 1e-6:
        v = v_d * cos(alpha) + k1 * rho
        omega = omega_d + k2 * alpha + k1 * (sin(alpha) * cos(alpha) / alpha) * (alpha + k2 * delta)
    else:
        v = v_d + k1 * rho
        omega = omega_d + k2 * alpha + k1 * cos(alpha) * (alpha + k2 * delta)
    return v, omega

# Tractor parameters
a1 = 0.15  # front wheel x-offset
a2 = 0.08  # rear wheel x-offset
t1 = 0.06
t2 = 0.04
D = 0.2
d = 0.1
l = 0.5
b = 0.10

# Controller gains
k1 = 3.0
k2 = 5.0

# Simulation parameters
dt = 0.01
T = 200
N = int(T / dt)

# Initial state
x = -2.0
y = 1.0
theta = 0.0

# Preallocate arrays
X = np.zeros(N)
Y = np.zeros(N)
THETA = np.zeros(N)
X_d = np.zeros(N)
Y_d = np.zeros(N)
X_f = np.zeros(N)
Y_f = np.zeros(N)
phi = np.zeros(N)
time = np.zeros(N)

for i in range(N):
    t = i * dt
    time[i] = t
    
    if t < 20:
        eta_f = np.array([-2, 1, 0])
        eta_d = np.array([0, 1, 0])
        eta_d_dot = np.array([0, 0, 0])
    elif t < 40:
        eta_f = np.array([0.2 * (t - 20), 1, 0])
        eta_d = np.array([0.2 * (t - 20), 1, 0])
        eta_d_dot = np.array([0.2, 0, 0])
    elif t < 60:
        eta_f = np.array([sin(0.05 * pi * (t - 40)) + 4,
                          -cos(0.05 * pi * (t - 40)) + 2,
                          0])
        thet = -pi/2 + (pi/20) * (t - 40)
        eta_d = np.array([4 + 2 * cos(thet), 3 + 2 * sin(thet), 0])
        eta_d_dot = np.array([-2 * (pi/20) * sin(thet), 2 * (pi/20) * cos(thet), 0])
    elif t < 80:
        eta_f = np.array([-0.2 * (t - 60) + 4, 3, 0])
        eta_d = np.array([-0.2 * (t - 60) + 4, 5, 0])
        eta_d_dot = np.array([-0.2, 0, 0])
    elif t < 100:
        eta_f = np.array([-sin(0.05 * pi * (t - 80)),
                          -cos(0.05 * pi * (t - 80)) + 4,
                          0])
        thet = -pi/2 + (pi/20) * (t - 80)
        eta_d = np.array([0 - 2 * cos(thet), 7 + 2 * sin(thet), 0])
        eta_d_dot = np.array([2 * (pi/20) * sin(thet), 2 * (pi/20) * cos(thet), 0])
    elif t < 120:
        eta_f = np.array([0.2 * (t - 100), 5, 0])
        eta_d = np.array([0.2 * (t - 100), 9, 0])
        eta_d_dot = np.array([0.2, 0, 0])
    elif t < 140:
        eta_f = np.array([sin(0.05 * pi * (t - 120)) + 4,
                          -cos(0.05 * pi * (t - 120)) + 6,
                          0])
        thet = -pi/2 + (pi/20) * (t - 120)
        eta_d = np.array([4 + 2 * cos(thet), 7 + 2 * sin(thet), 0])
        eta_d_dot = np.array([-2 * (pi/20) * sin(thet), 2 * (pi/20) * cos(thet), 0])
    elif t < 160:
        eta_f = np.array([-0.2 * (t - 140) + 4, 7, 0])
        eta_d = np.array([-0.2 * (t - 140) + 4, 9, 0])
        eta_d_dot = np.array([-0.2, 0, 0])
    elif t < 180:
        eta_f = np.array([-sin(0.05 * pi * (t - 160)),
                          -cos(0.05 * pi * (t - 160)) + 8,
                          0])
        thet = -pi/2 + (pi/20) * (t - 160)
        eta_d = np.array([0 - 2 * cos(thet), 9 + 2 * sin(thet), 0])
        eta_d_dot = np.array([2 * (pi/20) * sin(thet), 2 * (pi/20) * cos(thet), 0])
    else:
        eta_f = np.array([0.2 * (t - 180), 9, 0])
        eta_d = np.array([0.2 * (t - 180), 11, 0])
        eta_d_dot = np.array([0.2, 0, 0])

    X_d[i], Y_d[i] = eta_d[0], eta_d[1]

    v_d = np.linalg.norm(eta_d_dot[:2])
    omega_d = 0.0  # No feedforward angular velocity

    v, omega = unicycle_tracking_control(x, y, theta, eta_d[0], eta_d[1], eta_d[2], v_d, omega_d, k1, k2)

    # Update states
    x += v * cos(theta) * dt
    y += v * sin(theta) * dt
    theta += omega * dt
    theta = wrapToPi(theta)

    X[i] = x
    Y[i] = y
    THETA[i] = theta

    # Front wheel position for tractor animation (front wheel offset a1 along heading)
    X_f[i] = x + a1 * cos(theta)
    Y_f[i] = y + a1 * sin(theta)

    # Steering angle phi placeholder (you can replace with your model)
    phi[i] = 0

# --- Animation ---

fig, ax = plt.subplots()
ax.set_xlim(np.min(X_d) - 2, np.max(X_d) + 2)
ax.set_ylim(np.min(Y_d) - 2, np.max(Y_d) + 2)
ax.set_aspect('equal')
ax.grid(True)
ax.set_title('Tractor Trajectory Tracking')
ax.set_xlabel('X (m)')
ax.set_ylabel('Y (m)')

actual_line, = ax.plot([], [], 'b-', label='Actual Path')
desired_line, = ax.plot(X_d, Y_d, 'r--', label='Desired Path')
tractor_body, = ax.plot([], [], 'k-', linewidth=2)
front_wheel, = ax.plot([], [], 'ro', markersize=6)
rear_wheel, = ax.plot([], [], 'go', markersize=6)
time_text = ax.text(0.02, 0.95, '', transform=ax.transAxes)

ax.legend()

def draw_tractor(x, y, theta):
    # Simple tractor shape: rectangle body + two wheels as circles
    body_length = 0.6
    body_width = 0.3

    # Rectangle corners before rotation (centered at (x,y))
    corners = np.array([
        [body_length/2, body_width/2],
        [body_length/2, -body_width/2],
        [-body_length/2, -body_width/2],
        [-body_length/2, body_width/2],
        [body_length/2, body_width/2]
    ]).T  # shape (2,5)

    # Rotation matrix
    R = np.array([[cos(theta), -sin(theta)], [sin(theta), cos(theta)]])

    # Rotate and translate corners
    rotated = R @ corners
    xs = rotated[0, :] + x
    ys = rotated[1, :] + y
    return xs, ys

def init():
    actual_line.set_data([], [])
    tractor_body.set_data([], [])
    front_wheel.set_data([], [])
    rear_wheel.set_data([], [])
    time_text.set_text('')
    return actual_line, tractor_body, front_wheel, rear_wheel, time_text

def animate(i):
    actual_line.set_data(X[:i], Y[:i])
    xs, ys = draw_tractor(X[i], Y[i], THETA[i])
    tractor_body.set_data(xs, ys)
    # Front wheel position
    front_wheel.set_data(X_f[i], Y_f[i])
    # Rear wheel position opposite to front wheel on x axis
    rear_x = X[i] - a2 * cos(THETA[i])
    rear_y = Y[i] - a2 * sin(THETA[i])
    rear_wheel.set_data(rear_x, rear_y)
    time_text.set_text(f'Time = {time[i]:.1f} s')
    return actual_line, tractor_body, front_wheel, rear_wheel, time_text

ani = animation.FuncAnimation(fig, animate, frames=N, interval=10, blit=True, init_func=init)

plt.show()

# Final plot of paths
plt.figure()
plt.plot(X, Y, label="Actual")
plt.plot(X_d, Y_d, label="Desired", linestyle="--")
plt.title("Tractor Trajectory Tracking")
plt.xlabel("X (m)")
plt.ylabel("Y (m)")
plt.legend()
plt.grid(True)
plt.axis('equal')
plt.show()
