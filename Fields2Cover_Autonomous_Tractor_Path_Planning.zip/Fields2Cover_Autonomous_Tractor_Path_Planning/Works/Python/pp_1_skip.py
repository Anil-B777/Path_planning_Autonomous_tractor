import numpy as np
import matplotlib.pyplot as plt
from shapely.geometry import Polygon, LineString, Point
from shapely.geometry.polygon import orient
from shapely.affinity import scale
from matplotlib.patches import Polygon as MplPolygon
from matplotlib.collections import PatchCollection
import matplotlib.animation as animation
from dubins_curve import get_dubins_path_points
import math

velocity = 7

class Robot:
    def __init__(self, x, y, theta, linear_velocity, wheelbase=0.4):
        self.x = x
        self.y = y
        self.theta = theta
        self.v = linear_velocity  # CONSTANT VELOCITY
        self.wheelbase = 0.2  # Reduced for better turning (was 0.4)
        self.phi = 0.0
        self.dt = 0.01  # Smaller timestep for precision (was 0.01)
        self.length = 1.2
        self.width = 0.6
        self.wheel_length = 0.08
        self.wheel_width = 0.04
        
        # UNIFIED Pure pursuit parameters - same for all path types
        self.look_ahead_distance = 0.1  # CRITICAL: Shorter look-ahead for tight following
        self.max_steer_angle = np.radians(50)  # Slightly increased steering capability
        self.prev_target_idx = 0

    def pure_pursuit_control(self, path_points):
        """
        SIMPLIFIED Pure pursuit controller - no curve/straight distinction
        """
        # CONSTANT look-ahead distance for all scenarios
        look_ahead = self.look_ahead_distance
            
        current_pos = Point(self.x, self.y)
        
        # Find the closest point on the path (more efficient search)
        min_dist = float('inf')
        target_idx = self.prev_target_idx
        
        # Search starting from previous index
        search_range = min(50, len(path_points) - self.prev_target_idx)  # Limit search range
        for i in range(self.prev_target_idx, self.prev_target_idx + search_range):
            if i >= len(path_points):
                break
            dist = current_pos.distance(path_points[i])
            if dist < min_dist:
                min_dist = dist
                target_idx = i
        
        # Search forward for the look-ahead point
        for i in range(target_idx, len(path_points)):
            if current_pos.distance(path_points[i]) >= look_ahead:
                target_idx = i
                break
        
        # Update previous target index with bounds checking
        self.prev_target_idx = max(0, min(target_idx - 5, len(path_points) - 1))
        
        # Handle end of path
        if target_idx >= len(path_points):
            target_idx = len(path_points) - 1
            
        # Calculate steering angle using pure pursuit
        target_point = path_points[target_idx]
        
        # Angle to target point
        alpha = math.atan2(target_point.y - self.y, target_point.x - self.x) - self.theta
        alpha = math.atan2(math.sin(alpha), math.cos(alpha))  # Normalize to [-pi, pi]
        
        # Pure pursuit steering formula
        if abs(self.v) < 0.01:
            steering_angle = 0
        else:
            # Use actual look-ahead distance for calculation
            actual_lookahead = current_pos.distance(path_points[target_idx])
            actual_lookahead = max(actual_lookahead, 0.1)  # Minimum look-ahead
            steering_angle = math.atan2(2.0 * self.wheelbase * math.sin(alpha), actual_lookahead)
        
        # Limit steering angle
        steering_angle = np.clip(steering_angle, -self.max_steer_angle, self.max_steer_angle)
        
        return steering_angle, target_idx
        
    def move(self, path_points, target_point):
 # Get steering angle from pure pursuit controller
        steering_angle, _ = self.pure_pursuit_control(path_points)
        self.phi = steering_angle
    
    # Update vehicle state using bicycle model
        self.x += self.v * np.cos(self.theta) * self.dt
        self.y += self.v * np.sin(self.theta) * self.dt
        self.theta += (self.v / self.wheelbase) * np.tan(self.phi) * self.dt
       # self.theta = np.arctan2(np.sin(self.theta), np.cos(self.theta))  # Normalize angle
        
        return self.x, self.y, self.theta, self.phi
         
    def get_model(self):
        x, y, theta = self.x, self.y, self.theta
        phi = self.phi
        body_corners = [
            (-self.length/2, -self.width/2),
            (self.length/2, -self.width/2),
            (self.length/2, self.width/2),
            (-self.length/2, self.width/2)
        ]
        body_rotated = []
        for cx, cy in body_corners:
            rx = cx * np.cos(theta) - cy * np.sin(theta) + x
            ry = cx * np.sin(theta) + cy * np.cos(theta) + y
            body_rotated.append((rx, ry))
        body_patch = MplPolygon(body_rotated, closed=True)
        wheel_centers = [
            (self.wheelbase/2, self.width/3),
            (self.wheelbase/2, -self.width/3)
        ]
        wheel_patches = []
        for wx, wy in wheel_centers:
            wheel_corners = [
                (-self.wheel_length/2, -self.wheel_width/2),
                (self.wheel_length/2, -self.wheel_width/2),
                (self.wheel_length/2, self.wheel_width/2),
                (-self.wheel_length/2, self.wheel_width/2)
            ]
            wheel_rotated = []
            for cx, cy in wheel_corners:
                rx = cx * np.cos(phi) - cy * np.sin(phi) + wx
                ry = cx * np.sin(phi) + cy * np.cos(phi) + wy
                rx_global = rx * np.cos(theta) - ry * np.sin(theta) + x
                ry_global = rx * np.sin(theta) + ry * np.cos(theta) + y
                wheel_rotated.append((rx_global, ry_global))
            wheel_patches.append(MplPolygon(wheel_rotated, closed=True))
        return [body_patch] + wheel_patches
    
def interpolate_swath_points(swath_coords, num_points=10):
       
    # If swath has only two points (start and end), do simple linear interpolation
        if len(swath_coords) == 2:
           start, end = swath_coords
           t = np.linspace(0, 1, num_points)
           x = start[0] + t * (end[0] - start[0])
           y = start[1] + t * (end[1] - start[1])
           return [Point(x[i], y[i]) for i in range(num_points)]
    
    # For swaths with multiple points, calculate the total length
        total_length = 0
        segment_lengths = []
        for i in range(len(swath_coords) - 1):
            p1, p2 = swath_coords[i], swath_coords[i + 1]
            length = np.sqrt((p2[0] - p1[0])**2 + (p2[1] - p1[1])**2)
            total_length += length
            segment_lengths.append(length)
    
    # Normalize segment lengths
        if total_length > 0:
            normalized_lengths = [length / total_length for length in segment_lengths]
        else:
        # Handle zero-length path (shouldn't happen in practice)
            return [Point(swath_coords[0])] * num_points
    
    # Allocate points to each segment based on its relative length
        points_per_segment = [max(2, int(num_points * length)) for length in normalized_lengths]
    
    # Generate interpolated points for each segment
        interpolated_points = []
        for i in range(len(swath_coords) - 1):
            p1, p2 = swath_coords[i], swath_coords[i + 1]
            n_points = points_per_segment[i]
        
        # Linear interpolation for this segment
            t = np.linspace(0, 1, n_points)
            x = p1[0] + t * (p2[0] - p1[0])
            y = p1[1] + t * (p2[1] - p1[1])
        
        # Add all points except the last one (to avoid duplicates)
            segment_points = [Point(x[j], y[j]) for j in range(n_points - 1)]
            interpolated_points.extend(segment_points)
    
    # Add the final point of the swath
        interpolated_points.append(Point(swath_coords[-1]))
    
        return interpolated_points

        

def generate_curve(start, end, polygon_centroid, velocity, skip_swath, start_direction, end_direction, num_points=50):  # Increased points
    """
    Generate a curve between two points using Dubins path with improved parameters.
    """
    dist = np.sqrt((end[0] - start[0])**2 + (end[1] - start[1])**2)
    if dist < 0.001:
        return [start, end]
    
    # Improved vehicle parameters for better curve generation
    car_length = 1.0  
    car_width = 0.8   
    max_steering_angle_degrees = 70  # Increased for tighter turns
    turning_radius = 1  # Adjusted turning radius
    
    # Better theta calculations based on swath direction
    if start_direction == "left_to_right":
        start_theta = 0  # Facing east
    elif start_direction == "right_to_left":
        start_theta = np.pi  # Facing west
    else:
        # Direction from start to end
        dx = end[0] - start[0]
        dy = end[1] - start[1]
        start_theta = np.arctan2(dy, dx)
    
    if end_direction == "left_to_right":
        end_theta = 0  # Facing east
    elif end_direction == "right_to_left":
        end_theta = np.pi  # Facing west
    elif end_direction == "to_end":
        # Special case for final segment - direction towards the endpoint
        dx = end.x - end[0]  # Using global end_point here
        dy = end.y - end[1]
        end_theta = np.arctan2(dy, dx)
    else:
        # Direct opposite of start direction for U-turns
        end_theta = start_theta + np.pi if start_direction in ["left_to_right", "right_to_left"] else start_theta
        end_theta = np.arctan2(np.sin(end_theta), np.cos(end_theta))
    
    # Define start and end positions for Dubins path
    start_pos = (start[0], start[1], start_theta)
    end_pos = (end[0], end[1], end_theta)
    
    # Adjust number of points based on distance
    #dubins_num_points = max(2, int(num_points * (0.8 + 0.3 * velocity) * max(1, dist*2)))
    dubins_num_points = min(6, int(150 * max(1, dist)))
    # Get Dubins path points with improved error handling
    try:
        path_points, path_type, path_length = get_dubins_path_points(
            start_pos, end_pos, turning_radius, car_width/2, max_steering_angle_degrees, dubins_num_points
        )
    except Exception as e:
        print(f"Warning: Dubins path error: {e}, using simplified path")

        
    if not path_points:
        # Fallback to straight line if Dubins path fails
        print("Warning: Dubins path not found, using straight line")
    return path_points


def generate_swaths(polygon, a, b, velocity, swath_base_width=1.0):
    swath_width = swath_base_width
    direction = np.array([b[0] - a[0], b[1] - a[1]])
    direction = direction / np.linalg.norm(direction)
    perp_direction = np.array([-direction[1], direction[0]])
    swaths = [LineString([a, b])]
    min_proj = min([np.dot(perp_direction, v) for v in polygon.exterior.coords])
    max_proj = max([np.dot(perp_direction, v) for v in polygon.exterior.coords])
    proj = np.dot(perp_direction, a) + swath_width
    while proj <= max_proj:
        ref_point = np.array(a) + perp_direction * (proj - np.dot(perp_direction, a))
        swath = LineString([ref_point - 50 * direction, ref_point + 50 * direction])
        clipped_swath = polygon.intersection(swath)
        if not clipped_swath.is_empty and clipped_swath.geom_type == "LineString":
            # Check the direction of the clipped swath
            swath_coords = list(clipped_swath.coords)
            # Ensure left-to-right orientation for all swaths
            if swath_coords[0][0] > swath_coords[-1][0]:  # If right-to-left
                swath_coords = swath_coords[::-1]  # Reverse the coordinates
                clipped_swath = LineString(swath_coords)
            swaths.append(clipped_swath)
        proj += swath_width
    return swaths

def create_offset_polygon(polygon, offset_distance):
    scaled_polygon = scale(polygon, xfact=1 + offset_distance, yfact=1 + offset_distance, origin='centroid')
    return orient(scaled_polygon)

def determine_path_direction(start_point, end_point, first_swath):
    start_to_first = Point(first_swath.coords[0]).distance(Point(start_point))
    start_to_last = Point(first_swath.coords[-1]).distance(Point(start_point))
    return start_to_first < start_to_last

def generate_path(swaths, start_point, end_point, polygon_centroid, is_even_sided, velocity, robot_length, swath_width):
    path_points = []
    path_types = []
    path_points.append(start_point)
    path_types.append('straight')
    go_left_to_right = determine_path_direction(start_point, end_point, swaths[0])
    last_swath = swaths[-1]
    end_to_first = Point(last_swath.coords[0]).distance(end_point)
    end_to_last = Point(last_swath.coords[-1]).distance(end_point)
    last_swath_left_to_right = end_to_last < end_to_first
    skip_swath = robot_length > swath_width
    step = 2 if skip_swath else 1
    print(len(swaths))
    
    # Number of points to generate for each straight section
    num_straight_points = 50  # Match the number of points in curves
    
    for i in range(0, len(swaths), step):
        current_swath = swaths[i]
        if i == 0:
            # Get swath coordinates in the correct direction
            current_coords = list(current_swath.coords if go_left_to_right else reversed(current_swath.coords))
            
            # Interpolate more points along the straight swath
            interpolated_points = interpolate_swath_points(current_coords, num_straight_points)
            path_points.extend(interpolated_points)
            path_types.extend(['straight'] * len(interpolated_points))
        else:
            if i >= len(swaths) - step:
                current_coords = list(current_swath.coords if last_swath_left_to_right else reversed(current_swath.coords))
            else:
                should_go_left_to_right = (i // step) % 2 == 0
                current_coords = list(current_swath.coords if should_go_left_to_right else reversed(current_swath.coords))
            
            # Interpolate more points along the straight swath
            interpolated_points = interpolate_swath_points(current_coords, num_straight_points)
            path_points.extend(interpolated_points)
            path_types.extend(['straight'] * len(interpolated_points))
        
        if i < len(swaths) - step:
            next_swath = swaths[i + step]
            should_go_left_to_right = ((i // step) % 2 == 0) == go_left_to_right
            current_direction = "left_to_right" if should_go_left_to_right else "right_to_left"
            next_direction = "right_to_left" if should_go_left_to_right else "left_to_right"
            
            # Improved curve point selection
            if should_go_left_to_right:
                curve_start = current_swath.coords[-1]  # End of current swath
                curve_end = next_swath.coords[-1]  # Start of next swath
            else:
                curve_start = current_swath.coords[0]  # Start of current swath
                curve_end = next_swath.coords[0]  # End of next swath
                
            curve = generate_curve(curve_start, curve_end, polygon_centroid, velocity, 
                                 skip_swath=skip_swath, start_direction=current_direction, end_direction=next_direction)
            path_points.extend([Point(p) for p in curve])
            path_types.extend(['curve'] * len(curve))
    
    last_point = last_swath.coords[-1] if last_swath_left_to_right else last_swath.coords[0]
    final_direction = "left_to_right" if last_swath_left_to_right else "right_to_left"
    final_curve = generate_curve(last_point, (end_point.x, end_point.y), polygon_centroid, velocity, 
                               skip_swath=skip_swath, start_direction=final_direction, end_direction="to_end")
    path_points.extend([Point(p) for p in final_curve])
    path_types.extend(['curve'] * len(final_curve))
    path_points.append(end_point)
    path_types.append('straight')
    return path_points, path_types, go_left_to_right, last_swath_left_to_right

def run_simulation(velocity, max_iterations=3000):  # Increased max iterations
    vertices = [(0, 0), (8, 0), (8, 8), (0, 8)]
    polygon = orient(Polygon(vertices))
    polygon_centroid = polygon.centroid
    start_point = Point(0, 0)
    end_point = Point(8, 8)
    is_even_sided = len(vertices) % 2 == 0
    a, b = vertices[0], vertices[1]
    robot = Robot(start_point.x, start_point.y, 0, linear_velocity=velocity)
    robot_length = robot.length
    swath_base_width = 1
    print(f"Robot length: {robot_length}, Swath width: {swath_base_width}")
    swaths = generate_swaths(polygon, a, b, velocity, swath_base_width)

    # Generate path
    path_points, path_types, go_left_to_right, last_swath_left_to_right = generate_path(
        swaths, start_point, end_point, polygon_centroid, is_even_sided, velocity, robot_length, swath_base_width)
    
    # Generate non-skip-swath path for comparison
    non_skip_path_points, non_skip_path_types, _, _ = generate_path(
        swaths, start_point, end_point, polygon_centroid, is_even_sided, velocity, 0.5, swath_base_width)
    
    # Generate offset polygon
    offset_distance = 0.4
    offset_polygon = create_offset_polygon(polygon, offset_distance)
    
    robot_positions = [(robot.x, robot.y)]
    robot_states = [(robot.x, robot.y, robot.theta, robot.phi)]
    current_target_idx = 1
    iteration = 0
    
    # Progress tracking variables
    last_progress_point = (robot.x, robot.y)
    stuck_count = 0
    
    # Path following loop with pure pursuit controller
    while current_target_idx < len(path_points):
        iteration += 1
        
        # Get current and target points
        target_point = path_points[current_target_idx]
        x, y, theta, phi = robot.move(path_points, target_point)
        robot_positions.append((x, y))
        robot_states.append((x, y, theta, phi))
        
        # Calculate distance to target
        dist_to_target = np.sqrt((x - target_point.x)**2 + (y - target_point.y)**2)
        dist_to_end = np.sqrt((x - end_point.x)**2 + (y - end_point.y)**2)
        
        # Stop if the robot is very close to the end point
        if dist_to_end < 0.1:
            robot.v = 0
            print(f"Robot reached the end point at iteration {iteration}")
            break
        # Adaptive threshold based on curve status and velocity
        threshold = 0.001 
        
        # Check if target reached
        if dist_to_target < threshold:
            current_target_idx += 1
            print(f"Target {current_target_idx-1} reached at iteration {iteration}")
            
        # Special handling for final approach
        if iteration % 150 == 0:
            if len(robot_positions) > 150:
                recent_positions = robot_positions[-150:]
                total_movement = sum(np.sqrt((recent_positions[i][0] - recent_positions[i-1][0])**2 + 
                                           (recent_positions[i][1] - recent_positions[i-1][1])**2) 
                                 for i in range(1, len(recent_positions)))
                if total_movement < 0.5:  # Robot hasn't moved much
                    print(f"Robot appears stuck, skipping target at iteration {iteration}")
                    current_target_idx = min(current_target_idx + 5, len(path_points) - 1)
        
        if iteration >= max_iterations or current_target_idx >= len(path_points):
            break
    
    # Display results
    print(f"Simulation completed after {iteration} iterations")
    print(f"Final robot position: ({robot.x:.2f}, {robot.y:.2f})")
    print(f"Distance to end point: {np.sqrt((robot.x - end_point.x)**2 + (robot.y - end_point.y)**2):.2f}")
    fig, ax = plt.subplots(figsize=(8, 8))
    skip_swath = robot_length > swath_base_width
    step = 2 if skip_swath else 1
    
    # Plot ideal paths
    path_x, path_y = zip(*[(p.x, p.y) for p in path_points])
    ax.plot(path_x, path_y, color='green', linestyle='--', label='Ideal Path (Skip)' if skip_swath else 'Ideal Path', linewidth=2)
    
    if skip_swath:
        non_skip_path_x, non_skip_path_y = zip(*[(p.x, p.y) for p in non_skip_path_points])
        ax.plot(non_skip_path_x, non_skip_path_y, color='green', linestyle='--', label='Ideal Path (Non-Skip)', linewidth=2)
    
    robot_x, robot_y = zip(*robot_positions)
    ax.plot(robot_x, robot_y, color='red', label='Robot Trajectory', linewidth=1.5)
    ax.scatter(start_point.x, start_point.y, color='black', s=100, label='Start')
    ax.scatter(end_point.x, end_point.y, color='orange', s=100, label='End')
    poly_x, poly_y = zip(*vertices)
    ax.plot(poly_x + (poly_x[0],), poly_y + (poly_y[0],), 'k-', label='Polygon')
    offset_x, offset_y = zip(*offset_polygon.exterior.coords)
    ax.plot(offset_x, offset_y, color='black', linestyle='-.', label='Offset Polygon', linewidth=1.5)
    _robot = PatchCollection([])
    ax.add_collection(_robot)
    direction_text = "Left to Right" if go_left_to_right else "Right to Left"
    skip_text = "Dubins Curves, Skipping every other swath" if skip_swath else "No swath skipping"
    ax.set_title(f"Ackermann Robot with Pure Pursuit Controller (Velocity: {velocity}, {direction_text}, {skip_text})")
    ax.grid(True)
    ax.legend()
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')
    plt.axis('equal')
    def animate(i):
        patches = robot.get_model()
        robot.x, robot.y, robot.theta, robot.phi = robot_states[i]
        edgecolor = ['k'] * len(patches)
        facecolor = ['y'] + ['k'] * (len(patches) - 1)
        _robot.set_paths([p for p in patches])
        _robot.set_edgecolor(edgecolor)
        _robot.set_facecolor(facecolor)
        _robot.set_zorder(3)
        return _robot,
    base_interval = 100  # Base interval in milliseconds for velocity = 1
    adjusted_interval = max(5, int(base_interval / velocity))  # Lower interval = faster animation
    ani = animation.FuncAnimation(fig, animate, frames=len(robot_states), interval=adjusted_interval, repeat=False, blit=True)

    plt.show()
    plt.close()

def main():
    run_simulation(velocity)

if __name__ == "__main__":
    main()