import numpy as np
import matplotlib.pyplot as plt

def wrap_to_pi(angle):
    return (angle + np.pi) % (2 * np.pi) - np.pi

def unicycle_tracking_control(x, y, theta, x_d, y_d, theta_d, v_d, omega_d, k1, k2, k3):
    ex = x_d - x
    ey = y_d - y
    e_theta = wrap_to_pi(theta_d - theta)

    R = np.array([[np.cos(theta), np.sin(theta)], 
                  [-np.sin(theta), np.cos(theta)]])
    e = R @ np.array([ex, ey])
    e_x, e_y = e[0], e[1]

    v = v_d * np.cos(e_theta) + k1 * e_x
    omega = omega_d + k2 * v_d * e_y + k3 * np.sin(e_theta)
    return v, omega

# --- Parameters ---
dt = 0.01
T = 200
N = int(T / dt)

# Gains
k1, k2, k3 = 1.0, 2.0, 5.0

# Initialize states
x, y, theta = -2, 1, 0
X, Y = [], []
X_d, Y_d = [], []
X_f, Y_f = [], []

# Initialize plot
plt.figure(figsize=(10, 6))
plt.grid(True)
plt.axis("equal")
plt.xlim(-3, 6)
plt.ylim(0, 11)
plt.title("Unicycle Tracking - Real-Time Animation")
plt.xlabel("x")
plt.ylabel("y")

for i in range(N):
    t = i * dt

    if t < 20:
        eta_f = np.array([-2, 1, 0])
        eta_d = np.array([0, 1, 0])
        eta_d_dot = np.zeros(3)
        eta_d_ddot = np.zeros(3)
    elif t < 40:
        eta_f = np.array([0.2*(t - 20), 1, 0])
        eta_d = eta_f
        eta_d_dot = np.array([0.2, 0, 0])
        eta_d_ddot = np.zeros(3)
    elif t < 60:
        theta_tmp = -np.pi/2 + (np.pi/20)*(t - 40)
        eta_f = np.array([np.sin(0.05*np.pi*(t - 40)) + 4, -np.cos(0.05*np.pi*(t - 40)) + 2, 0])
        eta_d = np.array([4 + 2*np.cos(theta_tmp), 3 + 2*np.sin(theta_tmp), 0])
        eta_d_dot = np.array([-2*(np.pi/20)*np.sin(theta_tmp), 2*(np.pi/20)*np.cos(theta_tmp), 0])
        eta_d_ddot = np.array([-2*(np.pi/20)**2*np.cos(theta_tmp), -2*(np.pi/20)**2*np.sin(theta_tmp), 0])
    elif t < 80:
        eta_f = np.array([-0.2*(t - 60) + 4, 3, 0])
        eta_d = np.array([-0.2*(t - 60) + 4, 5, 0])
        eta_d_dot = np.array([-0.2, 0, 0])
        eta_d_ddot = np.zeros(3)
    elif t < 100:
        theta_tmp = -np.pi/2 + (np.pi/20)*(t - 80)
        eta_f = np.array([-np.sin(0.05*np.pi*(t - 80)), -np.cos(0.05*np.pi*(t - 80)) + 4, 0])
        eta_d = np.array([-2*np.cos(theta_tmp), 7 + 2*np.sin(theta_tmp), 0])
        eta_d_dot = np.array([2*(np.pi/20)*np.sin(theta_tmp), 2*(np.pi/20)*np.cos(theta_tmp), 0])
        eta_d_ddot = np.array([2*(np.pi/20)**2*np.cos(theta_tmp), -2*(np.pi/20)**2*np.sin(theta_tmp), 0])
    elif t < 120:
        eta_f = np.array([0.2*(t - 100), 5, 0])
        eta_d = np.array([0.2*(t - 100), 9, 0])
        eta_d_dot = np.array([0.2, 0, 0])
        eta_d_ddot = np.zeros(3)
    elif t < 140:
        eta_f = np.array([np.sin(0.05*np.pi*(t - 120)) + 4, -np.cos(0.05*np.pi*(t - 120)) + 6, 0])
        eta_d = np.array([4, 9, 0])
        eta_d_dot = eta_d_ddot = np.zeros(3)
    elif t < 160:
        eta_f = np.array([-0.2*(t - 140) + 4, 7, 0])
        eta_d = np.array([4, 9, 0])
        eta_d_dot = eta_d_ddot = np.zeros(3)
    elif t < 180:
        eta_f = np.array([-np.sin(0.05*np.pi*(t - 160)), -np.cos(0.05*np.pi*(t - 160)) + 8, 0])
        eta_d = np.array([4, 9, 0])
        eta_d_dot = eta_d_ddot = np.zeros(3)
    else:
        eta_f = np.array([0.2*(t - 180), 9, 0])
        eta_d = np.array([4, 9, 0])
        eta_d_dot = eta_d_ddot = np.zeros(3)

    x_d, y_d = eta_d[:2]
    dx_d, dy_d = eta_d_dot[:2]
    ddx_d, ddy_d = eta_d_ddot[:2]

    theta_d = np.arctan2(dy_d, dx_d)
    v_d = np.hypot(dx_d, dy_d)
    omega_d = (ddy_d * dx_d - ddx_d * dy_d) / (dx_d**2 + dy_d**2 + 1e-6)

    v, omega = unicycle_tracking_control(x, y, theta, x_d, y_d, theta_d, v_d, omega_d, k1, k2, k3)

    x += dt * v * np.cos(theta)
    y += dt * v * np.sin(theta)
    theta = wrap_to_pi(theta + dt * omega)

    # Store for later
    X.append(x)
    Y.append(y)
    X_d.append(x_d)
    Y_d.append(y_d)
    X_f.append(eta_f[0])
    Y_f.append(eta_f[1])

    # Plot real-time
    if i % 10 == 0:
        plt.cla()
        plt.grid(True)
        plt.axis("equal")
        plt.xlim(-3, 6)
        plt.ylim(0, 11)
        plt.title("Unicycle Tracking - Real-Time Animation")
        plt.xlabel("x")
        plt.ylabel("y")
        plt.plot(X, Y, 'b-', label="Tracked")
        plt.plot(X_d, Y_d, 'g--', label="Desired")
        plt.plot(X_f, Y_f, 'r:', label="Field")
        plt.plot(x, y, 'ko')  # current position
        plt.legend()
        plt.pause(0.001)

plt.show()
