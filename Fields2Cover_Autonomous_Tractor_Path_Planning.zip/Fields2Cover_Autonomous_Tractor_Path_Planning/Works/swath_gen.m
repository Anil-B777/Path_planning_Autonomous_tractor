clc; clear; close all;

%% 1. Define Irregular Field Polygon (example)
x = [0 10 12 8 4 2 0];   
y = [0 0 4 10 8 5 2];
field = polyshape(x, y);

% 1. Find centroid of polygon
[cx, cy] = centroid(field);

% 2. Define scale factor (e.g., 1.2 for 20% enlargement)
scale_factor = 1.2;

% 3. Compute scaled vertices
vertices = field.Vertices;
scaled_vertices = scale_factor * (vertices - [cx cy]) + [cx cy];

% 4. Create new scaled polygon
scaled_field = polyshape(scaled_vertices);

%% 2. Plot Polygon
figure; hold on; axis equal;
plot(field, 'FaceColor', [0 0 0], 'EdgeColor', 'g', 'LineWidth', 1.5);hold on;
plot(scaled_field, 'FaceColor', [1 0.6 0.6], 'EdgeColor', 'r', 'LineWidth', 1.5);
title('Horizontal Swath Generation Inside Polygon');
xlabel('X'); ylabel('Y');

%% 3. Parameters
swath_spacing =1;  % vertical spacing between horizontal swaths
swath_segments = {};

%% 4. Bounding box of polygon
verts = field.Vertices;
minx = min(verts(:,1)); maxx = max(verts(:,1));
miny = min(verts(:,2)); maxy = max(verts(:,2));

%% 5. Generate horizontal swaths covering the polygon
y_swaths = miny:swath_spacing:maxy;

for i = 1:length(y_swaths)
    y0 = y_swaths(i);
    h = 1e-3; % very thin height (almost a line)
    
    % Define a narrow horizontal rectangle representing the swath line
    swath_rect = polyshape([minx-10 maxx+10 maxx+10 minx-10], ...
                           [y0-h y0-h y0+h y0+h]);
    
    % Clip it with the polygon
    clipped = intersect(field, swath_rect);
    
    % Extract boundary points for clipped swath segments
    if ~isempty(clipped.Vertices)
        [xb, yb] = boundary(clipped);
        
        % Every pair of points form a line segment inside polygon
        for j = 1:2:length(xb)-1
            seg = [xb(j) yb(j); xb(j+1) yb(j+1)];
            swath_segments{end+1} = seg;
        end
    end
end

%% 6. Plot swath segments in alternating colors
for i = 1:length(swath_segments)
    seg = swath_segments{i};
    if mod(i,2) == 1
        plot(seg(:,1), seg(:,2), 'k', 'LineWidth', 2);
    else
        plot(seg(:,1), seg(:,2), 'k', 'LineWidth', 2);
    end
end

legend('Polygon', 'Swath lines');

% After you generate swath_segments (horizontal swaths inside polygon)
rho = 2;           % Minimum turning radius (adjust to tractor)
step_size = 0.1;   % Path resolution in meters

% Generate full Dubins trajectory
full_path = plan_dubins_trajectory(swath_segments, rho, step_size);

% Plot results
figure; hold on; axis equal;
plot(field, 'FaceColor', [0.6 1 0.6], 'EdgeColor', 'g', 'LineWidth', 1.5);

for i=1:length(swath_segments)
    seg = swath_segments{i};
    plot(seg(:,1), seg(:,2), 'r', 'LineWidth', 1.5);
end

plot(full_path(:,1), full_path(:,2), 'b-', 'LineWidth', 2);
plot(full_path(:,1), full_path(:,2), 'k', 'MarkerFaceColor', 'b');

title('Dubins Path Trajectory Tracking Swaths');
xlabel('X'); ylabel('Y');
legend('Polygon', 'Swath lines', 'Tractor Dubins Trajectory');



function [full_path] = plan_dubins_trajectory(swath_segments, rho, step_size)
    % swath_segments: cell array of line segments [2x2] endpoints
    % rho: minimum turning radius
    % step_size: discretization step
    
    % Sort swaths by Y
    midYs = zeros(length(swath_segments),1);
    for i = 1:length(swath_segments)
        seg = swath_segments{i};
        midYs(i) = mean(seg(:,2));
    end
    [~, idx] = sort(midYs);
    swath_segments = swath_segments(idx);
    
    full_path = [];
    
    for i = 1:length(swath_segments)
        seg = swath_segments{i};
        % Determine heading along segment
        dx = seg(2,1) - seg(1,1);
        dy = seg(2,2) - seg(1,2);
        heading = atan2(dy, dx);
        
        % Alternate direction for zig-zag
        if mod(i,2)==0
            seg = flipud(seg);
            heading = atan2(seg(2,2)-seg(1,2), seg(2,1)-seg(1,1));
        end
        
        % Define start and end pose of this swath line
        start_pose = [seg(1,1), seg(1,2), heading];
        end_pose = [seg(2,1), seg(2,2), heading];
        
        % Generate straight path along swath line
        n_points = ceil(norm(seg(2,:)-seg(1,:))/step_size);
        x_line = linspace(seg(1,1), seg(2,1), n_points);
        y_line = linspace(seg(1,2), seg(2,2), n_points);
        theta_line = heading*ones(1,n_points);
        swath_path = [x_line' y_line' theta_line'];
        
        % Connect from last swath end to this start using Dubins path if not first
        if i == 1
            full_path = swath_path;
        else
            last_pose = full_path(end,:);
            dubins_seg = dubins_path(last_pose, start_pose, rho, step_size);
            full_path = [full_path; dubins_seg(2:end,:)]; % skip duplicate point
            full_path = [full_path; swath_path];
        end
    end
end




function [path] = dubins_path(start_pose, end_pose, rho, step_size)
    % start_pose = [x0, y0, theta0]
    % end_pose   = [x1, y1, theta1]
    % rho = minimum turning radius
    % step_size = resolution of path points
    
    % This is a simplified Dubins path generator returning a set of [x,y,theta]
    % points along the path connecting start to end with turning radius rho.
    % For brevity, only handles CSC type (curve-straight-curve) path here.
    % For full coverage, you may want a full Dubins path library.
    
    % -- For full details see Dubins path papers or existing libraries --
    
    % Here, for simplicity, we:
    % 1) Compute circle centers for left and right turns at start and end
    % 2) Find tangent points between circles (CSC)
    % 3) Sample along the path segments
    
    % For demonstration, this function returns a straight line path (no turn)
    % You should replace with actual Dubins path code or library.
    
    % Return linear interpolation between start and end (dummy)
    n = ceil(norm(end_pose(1:2)-start_pose(1:2))/step_size);
    x = linspace(start_pose(1), end_pose(1), n);
    y = linspace(start_pose(2), end_pose(2), n);
    theta = linspace(start_pose(3), end_pose(3), n);
    path = [x' y' theta'];
end
