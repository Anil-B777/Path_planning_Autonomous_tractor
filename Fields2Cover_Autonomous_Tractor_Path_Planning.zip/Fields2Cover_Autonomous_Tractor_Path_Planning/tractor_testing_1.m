%% simple tractor kinematics
clc;clear; close all;
%% solver details
dt = 0.05;
ts = 160;
t = 0:dt:ts;
%% Tractor details

 a1 = 0.15; a2 = 0.08;
 t1 = 0.06; t2 = 0.04;
 D = 0.2; d = 0.1; l = 0.5; b = 0.10;
%% Initial conditions

eta = [-3;-1;0];
kc = 1; ks = 8;

%% numerical integration starts here
for i = 1:length(t)
    psi = eta(3,i);
    x(i) = eta(1,i);
    y(i) = eta(2,i);
%     xr(i) = 0.2*t(i);
   xr(i) = 1*cos(0.1*t(i));
    yr(i) = 1*sin(0.1*t(i));
%     xrdot = 0.2;
xrdot=-0.1*sin(0.1*t(i));
    yrdot = 0.1*cos(0.1*t(i));
    ex = xr(i)-x(i);
    ey = yr(i)-y(i);
    J = [cos(psi),-sin(psi),0;sin(psi),cos(psi),0;0,0,1];
%     zeta(:,i) = inv(J)*(eta_d_dot+kp*e);
%     u = sqrt(zeta(1,i)^2+zeta(2,i)^2); r = zeta(3,i);
    xd_dot = xrdot + ks*tanh(kc*ex);
    yd_dot = yrdot + ks*tanh(kc*ey);
    cont_l = [cos(psi),sin(psi);
              -1/l*sin(psi),1/l*cos(psi)]*[xd_dot;yd_dot];
    u = cont_l(1);
    r = cont_l(2);
    phi(i) = atan(l*r/u);
%     if abs(phi(i))>=45
%         phi(i) = 45*sign(phi(i));
%     end
    V(i) = u;
    W = [1;0;tan(phi(i))/l;];
    zeta(:,i) = W*V(i);
% zeta(:,i) = [u;0;r];
    eta(:,i+1) = eta(:,i) + J*zeta(:,i)*dt;
end
% plot(t,eta(:,1:i))


veh_box = [-b,b,b,l,l,b,b,-b,-b;-D,-D,-d,-d,d,d,D,D,-D];
wheel_s = [-a2,a2,a2,-a2,-a2;-t2/2,-t2/2,t2/2,t2/2,-t2/2];
wheel_b = [-a1,a1,a1,-a1,-a1;-t1/2,-t1/2,t1/2,t1/2,-t1/2];

for i = 1:5:length(t)
    psi = eta(3,i); 
    R = [cos(psi),-sin(psi);sin(psi),cos(psi)];
    v_m = R*veh_box;
    w_m3 = R*(wheel_b+[0;D+t1/2]);
    w_m4 = R*(wheel_b+[0;-D-t1/2]);
    R1 = [cos(phi(i)),-sin(phi(i));sin(phi(i)),cos(phi(i))];

    w_m1 = R*(R1*wheel_s+[l;d+t2/2]);
    w_m2 = R*(R1*wheel_s+[l;-d-t2/2]);
    fill(v_m(1,:)+x(i),v_m(2,:)+y(i),'y');
    hold on
    fill(w_m1(1,:)+x(i),w_m1(2,:)+y(i),'r');
    fill(w_m2(1,:)+x(i),w_m2(2,:)+y(i),'r');
    fill(w_m3(1,:)+x(i),w_m3(2,:)+y(i),'g');
    fill(w_m4(1,:)+x(i),w_m4(2,:)+y(i),'g');
    plot(xr,yr,'m--')
    plot(eta(1,1:i),eta(2,1:i),'b-')
    
    xmin = min(eta(1,:)) - 0.5;
    xmax = max(eta(1,:)) + 0.5;
    ymin = min(eta(2,:)) - 0.5;
    ymax = max(eta(2,:)) + 0.5;
    axis([xmin xmax ymin ymax])
    axis equal
    grid on
    xlabel('x,[m]')
    ylabel('y,[m]');
    pause(0.01)
    hold off
end