clc;
xd=DataXY(:,1);yd=DataXY(:,2);

figure(1);
plot(xd,yd,'b','linewidth',2);
set(gcf,'color','w');grid on;  xlabel('$x~[m]$','Interpreter','latex','FontSize',16);ylabel('$y~[m]$','Interpreter','latex','FontSize',16);
set(gca,'FontSize',16);set(gca,'TickLabelInterpreter','latex');

%% simulation parameter
dt=0.1; % step size
ts=1000; % simulation time
t=0:dt:ts; % Time span

%% initial conditions
x0=0.5;
y0=0.5;
psi0=pi/4;

eta0 = [x0;y0;psi0];
eta(:,1)=eta0;
kw=1;kv=0.5;

%% loop starts here
for i=1:length(xd)
    psi = eta(3,i); % current orientation in rad
    %Jacobian matrix
    J_psi = [cos(psi),-sin(psi),0;
             sin(psi),cos(psi),0;
             0,0,1];
    %% inputs
   x=eta(1,i); y=eta(2,i);
    s2=(x-xd(i))*cos(psi)+(y-yd(i))*sin(psi);
    s1=(x-xd(i))*sin(psi)-(y-yd(i))*cos(psi);
v=-kv*tanh(s2)
w1(i,1)=-kw*tanh(s1);
    w=-kw*tanh(s1);
    u=[1;0;w];

     eta_dot(:,i) = J_psi * u;

    %position propagation using Euler method
    eta(:,i+1) = eta(:,i)+ eta_dot(:,i)*dt; %state update
    % (generalized coordinates)
    
end
%%
l = 0.4; % length of the mobile robot
w = 0.2; % width of the mobile robot
% Mobile robot coordinates
box_v = [-l/2,l/2,l/2,-l/2,-l/2;
         -w/2,-w/2,w/2,w/2,-w/2;];   
figure
for i = 1:50:length(t)
    psi = eta(3,i);
    R_psi = [cos(psi), -sin(psi);
             sin(psi), cos(psi)]; % rotation matrix
    v_pos = R_psi * box_v;
    x = eta(1,i);
    y = eta(2,i);

    fill(v_pos(1,:) + x, v_pos(2,:) + y, 'g') % robot body
    hold on, grid on
    axis([-5 5 -5 5]), axis square

    % Plot heading direction as an arrow
    heading_length = 0.3;
    quiver(x, y, heading_length*cos(psi), heading_length*sin(psi), ...
           'r', 'LineWidth', 2, 'MaxHeadSize', 2)

    plot(eta(1,1:i), eta(2,1:i), 'b-'); % path
    legend('MR', 'Heading', 'Path')
    set(gca, 'fontsize', 24)
    xlabel('x,[m]'); ylabel('y,[m]');
    pause(0.01)
    hold off
end



