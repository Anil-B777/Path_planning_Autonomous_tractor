%-----Please extract the compressed file in a  folder and then run----%

clc; clear; 
% Load trajectory
load('DataXY.mat');       % Load precomputed reference trajectory from file
xd = DataXY(:,1);         % Extract x-coordinates of desired path
yd = DataXY(:,2);         % Extract y-coordinates of desired path
trajectory = [xd, yd];    % Combine into [x y] pairs for convenience
N = length(xd);           % Total number of trajectory points

% Parameters
dt = 0.1;               % Time step (s)
v = 0.1;                  % Constant linear velocity (m/s)-------------------->  Requirement mentioned
k_theta = 3;              % Proportional gain for heading error control
lookahead = 10;           % Number of points ahead of the closest point to track
max_steps = 20000;        % Maximum number of iterations for simulation
final_tolerance = 0.05;       % Position tolerance for stopping (m)
heading_tolerance = deg2rad(5); % Heading angle tolerance in radians (~5 degrees)

% Initial condition
x0 = 0; y0 = -2; psi0 = pi/4; % Initial position (x, y) and orientation (psi)
eta = zeros(3, max_steps);   % Preallocate state matrix: [x; y; psi]
eta(:,1) = [x0; y0; psi0];   % Assign initial state

step = 1;        % Start step counter
done = false;    % Flag to indicate completion

% Loop until done or max steps reached
while ~done && step < max_steps
    x = eta(1,step);    % Current x-position
    y = eta(2,step);    % Current y-position
    psi = eta(3,step);  % Current orientation

    % Compute distance to final goal
    dx_end = xd(end) - x;                                      % Difference in x from goal
    dy_end = yd(end) - y;                                      % Difference in y from goal
    dist_to_goal = hypot(dx_end, dy_end);          % Euclidean distance to goal
    heading_error_to_goal = wrapToPi(atan2(dy_end, dx_end) - psi); % Heading error to goal

    % Check stopping condition (close enough in both position and heading)
    if dist_to_goal < final_tolerance && abs(heading_error_to_goal) < heading_tolerance
        done = true;    % If within tolerances, stop simulation
        break;
    end

    % Find closest point on the trajectory to current position
    distances = vecnorm(trajectory - [x y], 2, 2);     % Euclidean distance to all points
    [~, idx_closest] = min(distances);                        % Index of closest point
    idx_target = min(idx_closest + lookahead, N);      % Lookahead target index, clamped to end

    % Target point to track
    x_t = xd(idx_target); % Target x
    y_t = yd(idx_target); % Target y

    % Compute control
    theta_d = atan2(y_t - y, x_t - x);    % Desired heading to target
    e_theta = wrapToPi(theta_d - psi);   % Heading error
    w = k_theta * e_theta;               % Only Control input is angular velocity-------------------------------->

    % Kinematic model integration (Euler method)
    eta_dot = [v * cos(psi);   % x dot
               v * sin(psi);   % y dot
               w];             % psi dot
    
    % Update robot state
    eta(:,step+1) = eta(:,step) + eta_dot * dt; % Discrete-time integration
    step = step + 1;                            % Advance step counter
end

% Trim unused columns (after final step)
eta = eta(:,1:step);

% Final plot of reference and actual path
figure(1); 
hold on;
plot(xd, yd, 'r', 'LineWidth', 2);                     % Plot desired trajectory in red
plot(eta(1,:), eta(2,:), 'b--', 'LineWidth', 2); % Plot actual path in blue dashed line
grid on; axis equal;                                      % Enable grid and equal aspect ratio
legend('Reference Trajectory', 'Tracked Path','Interpreter','latex','FontSize',18); % Legend
xlabel('$x~[m]$', 'Interpreter', 'latex', 'FontSize', 16); % x-axis label
ylabel('$y~[m]$', 'Interpreter', 'latex', 'FontSize', 16); % y-axis label
set(gca, 'FontSize', 16); set(gcf,'color','w');grid on; 
box on;
set(gca, 'TickLabelInterpreter','latex');      % Use LaTeX formatting for ticks


%% Animation of Robot
l = 1.8;    % length of the mobile robot
w = 1.4;    % width of the mobile robot
wheel_length = 0.3;
wheel_width = 0.5;

% Robot body shape
box_v = [-l/2, l/2, l/2, -l/2, -l/2;
         -w/2, -w/2, w/2, w/2, -w/2];

% Define wheel shape (centered at origin)
wheel_shape = [-wheel_length/2, wheel_length/2, wheel_length/2, -wheel_length/2, -wheel_length/2;
               -wheel_width/2, -wheel_width/2, wheel_width/2, wheel_width/2, -wheel_width/2];

% Wheel offsets (corners of the body)
wheel_offsets = [ l/2,  l/2, -l/2, -l/2;
                  w/2, -w/2,  w/2, -w/2];  % front-left, front-right, rear-left, rear-right

figure(2);
for i = 1:480:size(eta, 2)
 
    psi = eta(3,i);
    R_psi = [cos(psi), -sin(psi);
             sin(psi), cos(psi)];
    x = eta(1,i);
    y = eta(2,i);

    % Body
    v_pos = R_psi * box_v;
    fill(v_pos(1,:) + x, v_pos(2,:) + y, [0.2, 0.8, 0.2]) % green body 
    hold on;
    % Heading circle at the front
heading_offset = R_psi * [l/2; 0]; % front-center
theta_circ = linspace(0, 2*pi, 30);
r_heading = 0.4;
x_circ = r_heading * cos(theta_circ) + x + heading_offset(1);
y_circ = r_heading * sin(theta_circ) + y + heading_offset(2);
fill(x_circ, y_circ, 'b') % red circle

    hold on; grid on;
    axis([-3.5 24 -4 15]); axis square

    % Wheels
    for k = 1:4
        wheel_offset = wheel_offsets(:,k);
        wheel_pos = R_psi * wheel_offset;
        wheel = R_psi * wheel_shape;
        fill(wheel(1,:) + x + wheel_pos(1),wheel(2,:) + y + wheel_pos(2), 'k') % black wheels
    end

    % Heading arrow movement along the vector fields of tangent flow
    heading_length = 2.8;
    quiver(x, y, heading_length*cos(psi), heading_length*sin(psi), 'm', 'LineWidth', 3, 'MaxHeadSize', 2)

    % Path and reference
    plot(eta(1,1:i), eta(2,1:i), 'b-', 'LineWidth', 2);
    plot(xd, yd, 'r--', 'LineWidth', 1.5);hold on;
% legend('Robot', 'Heading', 'Tracked Path', 'Reference Trajectory');
title('Blue circle- front end, magenta arrow-heading direction','Interpreter','latex','FontSize',12)
set(gca, 'fontsize', 14)
set(gca, 'TickLabelInterpreter','latex');      % Use LaTeX formatting for ticks
set(gca, 'FontSize', 16); set(gcf,'color','w');grid on; 
box on;
xlabel('$x~[m]$', 'Interpreter', 'latex', 'FontSize', 16); ylabel('$y~[m]$', 'Interpreter', 'latex', 'FontSize', 16);
pause(0.01);
end
